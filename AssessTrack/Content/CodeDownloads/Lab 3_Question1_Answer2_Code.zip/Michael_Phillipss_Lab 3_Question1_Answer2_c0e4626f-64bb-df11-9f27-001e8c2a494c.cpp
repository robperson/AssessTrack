#include <iostream>                        
#include <string>                          
using namespace std;                       
                                          
                                           
int main()
{
		cout << "****************************" << endl;
		cout << "Michael Phillips" << endl;
		cout << "ID @02626480" << endl;
		cout << "SYCS-135 Comp Sci 1" << endl;
		cout << "Lab 3" << endl;
		cout << "September 7 2010" << endl;
		cout << "*****************************" << endl;

	        int side;                                     //Declare variable
        	cout << "Enter one side of the square=> ";    //Prompt user for the length of the side               
        	cin >> side;                                  //Get side from user     
		cout << "The area is " << side*side << endl;  //Output area
	    	return 0;                                     // return program completed OK to
                                                              // the operating system
     
//****************************
//Michael Phillips
//ID @02626480
//SYCS-135 Comp Sci 1
//Lab 3
//September 7 2010
//*****************************
//Enter one side of the square=> 10
//The area is 100
//Press any key to continue . . .

