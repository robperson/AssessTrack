#include <iostream>							// include input/output library code
#include <string>							// include string manipulate library code
using namespace std;						// allows all of the names in a namespace 
											// to be accessed without the namespace 
											// identifier as a qualifier

int main()
{		int mynumber;									// allows user to input a number
        cout << "***************************" << endl;
		cout << "Jeovane Slater-Taylor" << endl;		// identifies user name
        cout << "ID @02642186" << endl;					// identifies user id number
		cout << "SYCS-135 Computer Science 1" << endl;	// identifies course/course number
		cout << "Lab 3" << endl;						// identifies assignment name
		cout << "September 8, 2010" << endl;			// identifies date
		cout << "***************************" << endl;
		cout << "  " << endl;							// adds a space
		cout << "AREA CALCULATOR" << endl;
		cout << "  " << endl;
		cout << "Enter the number of inches of a side=> ";// prompts user to input a number
		cin >> mynumber;
		cout << "  " << endl;
		cout << "The area is " << mynumber*mynumber << endl;// produces the square of the number
		system("pause");					
		return 0;					 							
											
}        

//***************************
Jeovane Slater-Taylor
ID @02642186
SYCS-135 Computer Science 1
Lab 3
September 8, 2010
***************************

AREA CALCULATOR

Enter the number of inches of a side=> 12

The area is 144.