#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
#include <iomanip>
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
    float reimbursement;
	float beginning;
	float ending;
	cout << "***************************" << endl;
	cout << "Howard Student" << endl;
	cout << "ID @123456" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 7, 2010" << endl;
	cout << "***************************" << endl;
	cout << " " << endl;
	cout << "MILEAGE REIUMBURSEMENT CALCULATOR" << endl;
	cout << " " << endl;
	cout << "Enter beginning odomoter reading=> ";// 2.  prompt the user for the beginning odometer reading
	cin >> beginning;                     // 3.  get the reading from user
	cout << " " << endl;
	cout << "Enter ending odomoter reading=> ";// 2.  prompt the user for the ending odometer reading
	cin >> ending; //4.  get the reading from user
	cout << " " << endl;
	cout << fixed << showpoint;
	cout << setprecision(2) << "You traveled " << ending-beginning << " miles.  At $.35 per mile, your reimubursement is $" << (ending-beginning)*.35 << endl; // 4.  output message
	cout << " " << endl;
	return 0;                          // return program completed OK to
                                           // the operating system

}


/****************************
Howard Student
ID @123456
SYCS-135 Computer Science I
Lab 3
September 7, 2010
***************************

MILEAGE REIUMBURSEMENT CALCULATOR

Enter beginning odomoter reading=> 55044

Enter ending odomoter reading=> 55178

You traveled 134.00 miles.  At $.35 per mile, your reimubursement is $46.90*/
        