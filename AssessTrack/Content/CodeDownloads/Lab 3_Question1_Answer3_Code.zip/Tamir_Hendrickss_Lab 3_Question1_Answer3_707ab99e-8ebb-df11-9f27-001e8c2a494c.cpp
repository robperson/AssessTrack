#include <iostream>       // include input/output
#include <string>        // include string maniplate library code
using namespace std;    // allows all of names in the namespace

int main () 
{
cout<<"************************************"<<endl<<endl;
	cout<< "Tamir Hendricks"<<endl;
	cout<<"ID@02623129"<<endl;
	cout<<"SYCS-135 Computer Science"<<endl;
	cout<<"lab 3"<<endl;
	cout<<"September 8, 2010"<<endl;
	cout<<"************************************"<<endl<<endl;
	cout<<"MILEAGE REIMBURSMENT CALCULATOR"<<endl<<endl;

	float endmile;
	float begmile;
	cout<<"enter begining odometer reading=>xxx.x";
	cin >> "begmile";
	cout<<"enter ending odometer reading=>xxx.x";
	cin>> "endmile";
	cout<<"ending input-beginning input";
    cout<< "3.5 * 134.00;"
	include<iomanip>;
	cout<<"setprecison";
	return 0;
        