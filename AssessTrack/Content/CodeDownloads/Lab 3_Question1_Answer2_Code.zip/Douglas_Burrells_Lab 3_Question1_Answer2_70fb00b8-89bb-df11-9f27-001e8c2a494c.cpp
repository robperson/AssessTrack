#include <iostream> 
#include <string>
using namespace std;

int main()
{
        cout << "***************************** \n Douglas Burrell \n ID @02647671 \n SYCS-135 Computer Science I \n Lab 3 \n September 8, 2010 \n *************************** \n\n AREA CALCULATOR \n\n Enter the number of inches of a side=>";

		int side;
		cin>>side;
		cout << "the area is " << side * side;

	return 0;
}