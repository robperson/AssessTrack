#include <iostream>                      
#include <string>  
#include <iomanip>
using namespace std;                  
                                         
                                    
const float reimbursement = 0.35;
int main()
{
    cout << "****************************** \n " << endl;
    cout << "William Reid \nID: @02339317 \nSYS-135 Computer Science I \nLab 3 \nSeptember 7, 2010 \n " << endl;
    cout << "******************************" << endl;
    cout << " \nMILEAGE REIMBURSEMENT CALCULATOR \n " << endl;
    float initialodometer;
    float endodometer;   
    float mileage;
    float cashback;
    cout << "Enter beginning odometer reading => ";      
    cin >> initialodometer;   
    cout << " " << endl;
    cout << "Enter ending odometer reading => ";
    cin >> endodometer;
    mileage = endodometer - initialodometer;
    cashback = mileage * reimbursement;
    cout << " " << endl;
    cout << fixed << showpoint;
    cout << setprecision(2) << "You traveled " << mileage << " miles. At $0.35 per mile, your reimbursement is " << cashback << endl;
    return 0;                                                                           
}
//
// ******************************
//
// William Reid
// ID: @02339317
// SYS-135 Computer Science I
// Lab 3
// September 7, 2010
//
// ******************************
//
// MILEAGE REIMBURSEMENT CALCULATOR
//
// Enter beginning odometer reading => 12345
//
// Enter ending odometer reading => 98765
//
// You traveled 86420.00 miles. At $0.35 per mile, your reimbursement is 30247.00
// Press any key to continue . . .