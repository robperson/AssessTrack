#include <iomanip>
#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << "***************************" << endl;
	cout << "Najee K. Jeremiah" << endl;
	cout << "ID @02625680" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Assignment 3" << endl;
	cout << "september 8, 2010" << endl;
	cout << "***************************" << endl;
	cout << " " << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
	cout << " " << endl;
        float bmiles, emiles, distance, refund;                  // 1.  declare variables to store my values 
        cout << "Enter beginning odometer reading=> "; // 2.  prompt to enter a number
        cin >> bmiles;                              // 3.  get value from user
		cout << " " << endl;
		cout << "Enter ending odometer reading=> "; // 4.  prompt to enter a number
		cin >> emiles;                              // 5.  get value from user
		cout << " " << endl;
		distance = emiles - bmiles;            // 6. Subtract Ending Miles From Beginning Miles
		refund = distance * 0.35;              // 7. Multipy Rate by Distance Traveled
		cout << fixed << showpoint;
	    cout << showpoint << setprecision(2)<< "You traveled " << distance << " miles. At $.35 per mile your reimbursment is $" << refund << endl; // 5.  output message
		cout << " " << endl;
	    return 0;                         // return program completed OK to
                                           // the operating system
}
