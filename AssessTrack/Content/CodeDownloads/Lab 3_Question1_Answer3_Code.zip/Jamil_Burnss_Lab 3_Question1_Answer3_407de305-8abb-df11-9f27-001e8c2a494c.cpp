#include <iostream>		// include input/output library code
#include <string>		// include string manipulate library code
#include <iomanip>		// include input/output manipulate library code
using namespace std;	// allows all of the names in a namespace
						// to be accessed without the namespace
						// identifier as a qualifier

int main()
{
	
	cout << "***************************" << endl;	
	cout << "Jamil Burns" << endl;
	cout << "ID @02653333" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Assignment 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "***************************" << endl << endl; // header
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl; // purpose: calculate mileage reimbursemnt with constant $.35/mile
	int bor;								// 1. declare variable to store beginning odometer reading
	cout << "Enter beginning odometer reading=> "; // 2. prompt user to enter beginning odometer reading
	cin >> bor;								// 3. get beginning milelage from user
	cout << " " << endl;	
	int eor;								// 4. declare variable to store ending odometer reading
	cout << "Enter ending odometer reading=> ";	// 5. prompt user to enter ending odometer reading
	cin >> eor;								// 6. get ending mileage from user
	cout << " " << endl;
	cout << "You traveled " << eor-bor << " miles.  "; // 7. miles traveled output message
	cout << fixed << showpoint;				// 8. fix value to two decimal places
	cout << setprecision(2) << "At $.35 per mile, your reimbursement is $" << (eor-bor)*.35 << "." << endl; // 9. reimbursement output message
	cout << " " << endl;
	return 0;								// return program completed OK to
											// the operating system
											//***************************
											//Jamil Burns
											//ID @02653333
											//SYCS-135 Computer Science I
											//Assignment 3
											//September 8, 2010
											//***************************
											//
											//MILEAGE REIMBURSEMENT CALCULATOR
											//
											//Enter beginning odometer reading=> 55044
											//
											//Enter ending odometer reading=> 55178
											//
											//You traveled 134 miles.  At $.35 per mile, your reimbursement is $46.90.
											//
											//Press any key to continue . . .
}