#include <iostream>       // include input/output
#include <string>        // include string maniplate library code
using namespace std;    // allows all of names in the namespace

int main () 
{
	cout<<"************************************"<<endl<<endl;
	cout<< "Tamir Hendricks"<<endl;
	cout<<"ID@02623129"<<endl;
	cout<<"SYCS-135 Computer Science"<<endl;
	cout<<"lab 3"<<endl;
	cout<<"September 8, 2010"<<endl;
	cout<<"************************************"<<endl<<endl;
	cout<<"AREA CALCULATOR"<<endl<<endl;


	int number;                                                                        
	cout<<"Enter the number of inches of a side=>";   // prompt the user for number of inches
	cin>> number;                                      // get the number
	cout<<"the area is " <<number*number<<endl;      // multiply the two variables
    return 0;                                        // return program completed ok to 
	                                                //the operating system
}

************************************

Tamir Hendricks
ID@02623129
SYCS-135 Computer Science
lab 3
September 8, 2010
************************************

AREA CALCULATOR

Enter the number of inches of a side=>12
the area is 144

Press any key to continue . . .