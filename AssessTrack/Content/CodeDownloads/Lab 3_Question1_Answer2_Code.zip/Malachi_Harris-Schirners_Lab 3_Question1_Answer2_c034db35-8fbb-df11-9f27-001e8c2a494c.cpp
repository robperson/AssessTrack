#include <iostream>                        
#include <string>                          
using namespace std;                       
                                           
                                           

int main()
{
	cout << "***************************" << endl;
	cout << "Malachi Harris-Schirner" << endl;
	cout << "ID @02645004" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8,2010" << endl;
	cout << "***************************" << endl << endl;
	cout << "AREA CALCULATOR" << endl << endl; 
	int number;
	cout << "Enter one side of the square=> " << endl;
	cin >> number;
	cout << "the area is " << number*number << endl;
	 
}
// ***************************
// Malachi Harris-Schirner
// ID @02645004
// SYCS-135 Computer Science I
// Lab 3
// September 8,2010
// ***************************

// AREA CALCULATOR

// Enter one side of the square=>
// 12
// the area is 144