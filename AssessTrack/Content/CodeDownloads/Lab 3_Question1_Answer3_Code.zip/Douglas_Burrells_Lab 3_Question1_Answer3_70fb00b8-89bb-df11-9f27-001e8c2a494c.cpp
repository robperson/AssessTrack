#include <iostream> 
#include <string>
using namespace std;

int main()
{
        cout << "***************************** \n Douglas Burrell \n ID @02647671 \n SYCS-135 Computer Science I \n Lab 3 \n September 8, 2010 \n *************************** \n\n MILEAGE REIMBURSEMENT CALCULATOR \n\n";
		double odo;
		double odo2;
		cout<< "Enter beginning odometer reading=>";
		cin>>odo;
		cout<<	"Enter ending odometer reading=>";
		cin>>odo2;
		cout << "You traveled " << odo2-odo << " miles. At $.35 per mile, your reimbursement is \n " << (odo2 - odo) * 0.35;

	return 0;
}