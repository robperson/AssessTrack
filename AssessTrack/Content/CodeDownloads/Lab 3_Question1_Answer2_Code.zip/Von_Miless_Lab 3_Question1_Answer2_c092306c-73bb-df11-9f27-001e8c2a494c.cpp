#include<iostream> 
#include<string> 
using namespace std;

int main() 
{
	cout<< "******************************** "<< endl; 
	cout<< "Von Miles "<< endl; 
	cout<< "ID @02652433 "<< endl; 
	cout<< "SYCS - 135 Computer Science I "<< endl; 
	cout<< "Lab 3 "<< endl; 
	cout<< "September 8 2010 "<< endl; 
	cout<< "******************************** "<< endl; 
	
	int toSquare; 
	cout << "AREA CALCULATOR "<<endl; 
	cout<< "Enter the lenght of a side: "<<endl; 
	cin >> toSquare; 
	toSquare = toSquare * toSquare;
	cout << "The Area is " << toSquare << endl; 
	return 0; 
}


/*********************************
Von Miles
ID @02652433
SYCS - 135 Computer Science I
Lab 3
September 8 2010
********************************
AREA CALCULATOR
Enter the lenght of a side:
5
The Area is 25
Press any key to continue . . .*/ 