#include <iostream>                        
#include <string> 
#include <iomanip>
using namespace std;                       
                                      
int main()
{
        float readingStart;
	float readingEnd;
	float distance;
	float reimbursement;
	cout << fixed << showpoint;
        cout << "*************************** "<< endl;//1) prompt user input
	cout << "Howard Student "<< endl;//2) get user input
	cout << "ID @123456 "<< endl;//3) multiply input by itself
	cout << "SYCS-135 Computer Science I "<< endl;//4) output data 
	cout << "Lab 3 "<< endl;
	cout << "September 7, 2010 "<< endl;
	cout << "***************************  \n\n";
	cout << "MILEAGE REIMBURSEMENT CALCULATOR \n\n";
	cout << "Enter beginning odometer reading=>\n\n";
	cin	 >> readingStart;
	cout << "Enter ending odometer reading=>\n\n";
        cin  >> readingEnd;
	distance= readingEnd - readingStart;
	reimbursement= distance * .35;
	cout << setprecision (2) << "You traveled "<< distance << " miles. At $.35  per mile, your reimbursement is $"<<reimbursement << endl;
	system ("pause");
	return 0;
        