#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace
                                           // to be accessed without the namespace
                                           // identifier as a qualifier

int main()
{
    cout << "****************************** \n " << endl;
    cout << "William Reid \nID: @02339317 \nSYS-135 Computer Science I \nLab 3 \nSeptember 7, 2010 \n " << endl;
    cout << "******************************" << endl;
    cout << " \nAREA CALCULATOR \n " << endl;
    int myNumber;
    int myArea;                                      
    cout << "Enter one side of the square => ";       // Prompt user input  
    cin >> myNumber;                                  // Get user input
    myArea = myNumber * myNumber;                      // Multiply input by itself
    cout << "The area is => "<< myArea << endl;          // Output data
    return 0;                                       
                                                       
}
//
// ******************************
//
// William Reid
// ID: @02339317
// SYS-135 Computer Science I
// Lab 3
// September 7, 2010
//
// ******************************
//
// AREA CALCULATOR
//
// Enter one side of the square => 7
// The area is => 49
// Press any key to continue . . .
        