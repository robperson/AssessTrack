#include <iostream>         
#include <string>           
using namespace std;       

int main()
{
	cout << "***************************" << endl;   
	cout << "Eddie Faulk" << endl;
	cout << "@02652321" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 7, 2010" << endl;
	cout << "***************************" << endl << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
	int Beginning;
	int Ending;
	float Difference;
	cout << "Enter beginning odometer reading" << endl;
	cin >>Beginning;
	cout << "Enter ending odometer reading" << endl;
	cin >>Ending;
	Difference= Ending-Beginning;
	cout << "You traveled"" " << Difference <<" " "miles" << endl;
	return 0;
}
/*
	***************************
Eddie Faulk
@02652321
SYCS-135 Computer Science I
Lab 3
September 7, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading
55044
Enter ending odometer reading
55178
You traveled 134 miles

I had trouble after this part!
*/

        