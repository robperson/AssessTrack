#include <iostream>                        
#include <string>                          
using namespace std;                                                                                                          
int main()
{
		int side;
		cout << "**************************" << endl;
		cout << "Ronnie Shaw" << endl;
		cout << "ID @02648299" << endl;
		cout << "SYCS-135 Computer Science I" << endl;
		cout << "lab 3" << endl;
		cout << "September 8, 2010" << endl;
		cout << "**************************" << endl << endl;
		cout << "AREA CALCULATOR" << endl << endl;
		cout << "Enter the number of inches of a side=> "; 
		cin >> side;
		cout << endl;
		cout << "The area is " << side*side <<endl;
		return 0;
}
/***************************
Ronnie Shaw
ID @02648299
SYCS-135 Computer Science I
lab 3
September 8, 2010
**************************

AREA CALCULATOR

Enter the number of inches of a side=> 12

The area is 144*/
        