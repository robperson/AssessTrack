#include <iostream>
using namespace std;

int main ()
{
	cout << "hello rodney" << endl;
	return 0;
}

//hello rodney
        