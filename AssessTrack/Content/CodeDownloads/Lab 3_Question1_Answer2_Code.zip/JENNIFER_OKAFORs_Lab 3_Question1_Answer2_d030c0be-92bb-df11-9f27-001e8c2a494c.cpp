#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
        cout << "**************************" <<endl;				//output message
		cout << "Jennifer Okafor" <<endl;							//output message
		cout << "ID @02624575" <<endl;								//output message
		cout << "SYCS-135 Computer Science I" <<endl;				//output message
		cout << "Lab 3" <<endl;										//output message
		cout << "September 7, 2010" <<endl;							//output message
		cout << "**************************" <<endl<<endl;			//output message
		cout << "AREA CALCULATOR" <<endl<<endl;						//output message
		int lengthofoneside;										//declare variable to store length of square
		cout << "Enter the number of inches of a side=> ";			//prompt user for length of square
		cin >> lengthofoneside;										//get length of square from user				
		cout << "\nThe area is "<< lengthofoneside*lengthofoneside << endl;	//output message
		return 0;													//return program completed OK to the operating system
}

/* **************************
Jennifer Okafor
ID @02624575
SYCS-135 Computer Science I
Lab 3
September 7, 2010
**************************

AREA CALCULATOR

Enter the number of inches of a side=> 12

The area is 144
Press any key to continue . . .
*/