#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
  cout << fixed << showpoint;
  cout << setprecision(2);
  cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
  cout << endl;
  double beginning; 
  cout << "Enter beginning odometer reading=> "; //prompt user input
  cin >> beginning;                              //get user input
  cout << endl;
  double ending;
  cout << "Enter ending odometer reading=> ";  //prompt user input
  cin >> ending;                               //get user input
  cout << endl;
  cout << setprecision(2) << "You traveled " << ending-beginning;  //subtract ending input from beginning input
  cout << " miles. ";
  cout << "At $.35 per mile, ";
  cout << "your reimbursement is $" <<(ending-beginning)*.35;      //multiply difference by .35
  cout << "." << endl;                                             //output data         
  cout << endl;
  cout << "Press any key to continue..." << endl;
  return 0;
}
        