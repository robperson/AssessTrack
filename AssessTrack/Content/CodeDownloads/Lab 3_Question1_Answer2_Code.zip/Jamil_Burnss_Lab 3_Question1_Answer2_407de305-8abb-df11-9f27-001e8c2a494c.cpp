#include <iostream>			// include input/output library code
#include <string>			// include string manipulate library code
using namespace std;		// allows all of the names in a namespace
							// to be accessed without the namespace
							// identifier as a qualifier

int main()
{
	cout << "***************************" << endl;
	cout << "Jamil Burns" << endl;
	cout << "ID @02653333" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "***************************" << endl << endl;	// header
	cout << "AREA CALCULATOR" << endl << endl;				// purpose: calculate the area of a square
	int side;												// 1. declare variable to store side value
	cout << "Enter the number of inches of a side=> ";		// 2. prompt user to enter value
	cin >> side;											// 3. get side value from user
	cout << " " << endl;									//
	cout << "The area is " << side*side << endl;			// 4. output message
	return 0;												// return program completed OK to
															// the operating system
															// ***************************
/*Jamil Burns
ID @02653333
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***************************

AREA CALCULATOR

Enter the number of inches of a side=> 12

The area is 144
Press any key to continue . . .*/ 
}
