#include <iomanip>
#include <string>
using namespace std;

int main()
{
	float begin;
	float end;
	cout << "************* \n Sean Oxley \n ID @02645814 \n SYCS-135 Computer Science I \n Lab 3 \n Sept 8, 2010 \n************* " << endl << endl;
	cout << "Mileage Reimbursement Calculator" << endl << endl;
	cout << "Enter beginning odometer reading=>" << endl;
	cin >> begin;
	cout << "Enter ending odometer reading=>" << endl;
	cin >> end;
	cout << "You traveled " << end-begin << " miles. At $.35 per mile, your reimbursement is $" << (end-begin)*.35 endl;
	cout << fixed << showpoint;

	return 0;
}        