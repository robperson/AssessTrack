#include <iostream>                        
#include <string>
#include <iomanip>
using namespace std;                       
int main()
{
    float odometerstart;   
	float odometerfinish; 
	float reinbursment;
	float totalmiles;
	cout<<"******************* \n";
		cout<<"Howard Student \n";
		cout<<"ID @02606296 \n";
		cout<<"SYCS-135 Computer Science I\n";
		cout<<"Lab 3 \n";
		cout<<"September 8, 2010 \n";
		cout<<"******************** \n \n";
		cout<<"MILEAGE REINBURSMENT \n \n";
		cout<<"Enter beginning odometer reading =>"; //Promt user input 
		cin>> odometerstart; //Get user input
		cout<<"Enter ending odometer reading =>"; //Prompt user input
		cin>> odometerfinish; // Get user input
		totalmiles= odometerfinish-odometerstart; //subtract ending input from beginning
		reinbursment= .35*totalmiles; //Multiply difference by .35
		cout<< fixed << showpoint;
		cout<<setprecision(2)<<"You traveled " << totalmiles; //Output data
		cout <<setprecision(2)<< " Miles. At $.35 a mile, your reinbursement is $" << reinbursment;//output data
return 0;
}
//*******************
//Howard Student
//ID @02606296
//SYCS-135 Computer Science I
//Lab 3
//September 8, 2010
//********************

//MILEAGE REINBURSMENT

//Enter beginning odometer reading =>543534.6
//Enter ending odometer reading =>634534.2
//You traveled 90999.56 Miles. At $.35 a mile, your reinbursement is $31849.85Pres
//s any key to continue . . .