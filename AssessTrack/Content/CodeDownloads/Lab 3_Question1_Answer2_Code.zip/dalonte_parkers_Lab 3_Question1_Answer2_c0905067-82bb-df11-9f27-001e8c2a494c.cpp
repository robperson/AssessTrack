
        ***********************************
Dalonte Parker
ID @02650202
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***********************************
AREA CALCULATOR
Enter the number of inches of a side=> x
5
the area is y 25
