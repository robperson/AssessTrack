#include <iomanip>
#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout<<"***************************"<<endl;
	cout<<"Howard Student" <<endl;
	cout<<"ID @123456"<<endl;
	cout<<"SYCS-135 Computer Science I"<<endl;
	cout<<"Lab 3"<<endl;
	cout<<"September 7, 2010"<<endl;
	cout<<"***************************"<<endl;
	cout<<""<<endl;
	cout<<"MILEAGE REIMBURSEMENT CALCULATOR"<<endl;
	cout<<""<<endl;
	int odometer;
	int odometer2;
	cout<<"Enter beginning odometer reading=> ";
	cin>> odometer;
	cout<<"\nEnter ending odometer reading=> ";
	cout<< fixed << showpoint;
	cin>> odometer2;
	cout<<setprecision(2)<<"You traveled" << odometer2 - odometer << "miles. At $.35 per mile, your reimbursement is "<< (odometer2 - odometer) *0.35<<endl;
	return 0;
}
/****************************
Howard Student
ID @123456
SYCS-135 Computer Science I
Lab 3
September 7, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044

Enter ending odometer reading=> 55178
You traveled134miles. At $.35 per mile, your reimbursement is 46.90
Press any key to continue . . .*/
