#include <iostream>                        // include input/output library code
#include <string>  
#include <iomanip>							// include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier
int main()
{	cout << "****************************"<<endl;
	cout << "J.R. Akinkuowo"<<endl;
	cout << "ID @02641281"<<endl;
	cout << "SYCS-135 Computer Science I"<<endl;
	cout << "Assignment 3"<<endl;
	cout << "September 7, 2010"<<endl;
	cout << "****************************"<<endl<<endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR"<<endl<<endl;
	float beginning;
	float ending;
	float totalmiles;
	cout << endl << "Enter beginning odometer reading=> "; // prompt user input
	cin >> beginning;
	cout << endl << "Enter ending odometer reading=> "; // get user input
	cin >> ending;
	cout << fixed << showpoint;
	totalmiles=ending-beginning; // subtract ending input from beginning input
	cout << endl << "You traveled "<<setprecision(2)<<totalmiles 
		<< " miles. At $.35 per mile, your reimbursement is $" 
		<<(ending-beginning)* 0.35 << endl<<endl; // multiply difference by .35
	return 0; // output data           
}

/*****************************
J.R. Akinkuowo
ID @02641281
SYCS-135 Computer Science I
Assignment 3
September 7, 2010
****************************

MILEAGE REIMBURSEMENT CALCULATOR


Enter beginning odometer reading=> 55044 

Enter ending odometer reading=> 55178 

You traveled 134.00 miles. 

At $.35 per mile, 

your reimbursement is $46.90 

Press any key to continue . . .*/