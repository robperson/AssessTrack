#include <iostream> 
using namespace std; 
 

int main() 
{
cout << "***************************" << endl; 
cout << "Kahlil Vinson" << endl; 
cout << "ID @02641830" << endl; 
cout << "sycs-135 computer science I" << endl; 
cout << "Lab 3" << endl; 
cout << "September 7, 2010" << endl; 
cout << "***************************" << endl << endl; 
cout << "AREA CALCULATOR" << endl << endl; 
int side;
int area;										// 1.  declare variable to side 
cout << "enter the number of inches of a side ";	// 2.  prompt the user for their side
cin >> side;											// 3.  get area
area = side * side;
cout << "area is " << area << endl;						// 4.  output message
	return 0;											// return program completed OK to
														 // the operating system
														// 
}/****************************
Kahlil Vinson
ID @02641830
sycs-135 computer science I
Lab 3
September 7, 2010
***************************

AREA CALCULATOR

enter the number of inches of a side 12
area is 144
Press any key to continue . . . */        