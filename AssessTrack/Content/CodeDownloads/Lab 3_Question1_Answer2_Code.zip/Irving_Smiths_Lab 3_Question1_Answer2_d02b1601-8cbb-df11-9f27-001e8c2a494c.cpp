#include <iostream>		// include input/output library code
#include <string>		// include string manipulate library code
using namespace std;	// allows all of the names in a namespace 
						// to be accessed without the namespace 
						// identifier as a qualifier
int main()
{
	cout << "***************************\n"; 
	cout << "Irving Smith\n";
	cout << "ID @02642732\n";
	cout << "SYCS-135 Computer Science I\n";
	cout << "Lab 3\n";
	cout << "September 8, 2010\n";
	cout << "***************************\n ";
	cout << " \n";
	cout << "SQUARE AREA CALCULATOR\n ";
	cout << " \n";
	int yournumber;
	cout << "Enter one side of the square=> ";
	cin >> yournumber;
	cout << "\nThe area is " << yournumber * yournumber <<endl;
	return 0;
/* ***************************
Irving Smith
ID @02642732
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***************************

SQUARE AREA CALCULATOR

Enter one side of the square=> 12

The area is 144
Press any key to continue . . . */
}