#include <iostream>
#include <string>
using namespace std;

int main ()
{
	int side;
	int area;
	cout <<"Enter one side of the square=> "<<endl;
	cin >> side;
	area=(side*side);
	cout <<"The area is " << area <<endl;
	system("pause");
	return 0;
}
/*Enter one side of the square=>
45
The area is 2025
Press any key to continue . . .*/