#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    cout << "*****************************" << endl;
    cout << "Samuel Omosuyi" << endl;
    cout << "@02623937" << endl;
    cout << "Sycs-135 Computer Science 1" << endl;
    cout << "Assignment 3" << endl;
    cout << "September 7, 2010" << endl;
    cout << "*****************************" << endl << endl;

    cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
    
    cout << fixed << showpoint;
    float 
x;                                                                                                            
// 1.  declare variable to store the beginning odometer 
reading                    

    cout << "Enter beginning odometer reading = 
";                                                                      // 2.  
prompt the user for the beginning reading
    cin >> 
x;                                                                                                          
// 3.  get reading from user
    
    float 
y;                                                                                                            
// 4.  declare variable to store the ending odometer reading
    cout << "Enter ending odometer reading = 
";                                                                          // 
5.  prompt the user for the ending reading
    cin >> 
y;                                                                                                          
// 6.  get reading from user
    
    float 
xy;                                                                                                          
// 7.  declare variable to store the difference of both readings
    xy = y - 
x;                                                                                                        
// 8.  calculates the difference of beginning from ending reading
    
    float 
xyz;                                                                                                          
// 9.  declare variable to store reimbursement
    xyz = xy * 
.35;                                                                                                    
// 10. Calculates the reimbursement using difference multiplied by .35
    cout << setprecision(2) << "You traveled " << xy << "miles .At $.35 miles, 
your reimbursement is $" << xyz << endl;  // 11.  output message 

    return 
0;                                                                                                          
// 12.  return program completed OK to
                                                                                                                        
// 13.  the operating system
}

//*****************************
//Samuel Omosuyi
//@02623937
//Sycs-135 Computer Science 1
//Assignment 3
//September 7, 2010
//*****************************

//MILEAGE REIMBURSEMENT CALCULATOR

//Enter beginning odometer reading = 100
//Enter ending odometer reading = 200
//You traveled 100.00miles .At $.35 miles, your reimbursement is $35.00
