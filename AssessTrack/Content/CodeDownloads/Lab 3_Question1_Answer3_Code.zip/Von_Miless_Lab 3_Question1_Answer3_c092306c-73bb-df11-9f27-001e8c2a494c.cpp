#include<iostream> 
#include<string> 
using namespace std;

int main() 
{
	cout<< "******************************** "<< endl; 
	cout<< "Von Miles "<< endl; 
	cout<< "ID @02652433 "<< endl; 
	cout<< "SYCS - 135 Computer Science I "<< endl; 
	cout<< "Lab 3 "<< endl; 
	cout<< "September 8 2010 "<< endl; 
	cout<< "******************************** "<< endl; 
	
	float startodometer, finishodometer, reimbursment;
	cout<< "Enter beginning odometer reading => " <<endl;
	cin>> startodometer;  
	cout<< "Enter ending odometer reading => " <<endl;
	cin>> finishodometer;
	cout<< finishodometer-startodometer <<endl;
	reimbursment=finishodometer-startodometer;
	cout<< reimbursment*.35; 
	


	return 0; 
}

/*********************************
Von Miles
ID @02652433
SYCS - 135 Computer Science I
Lab 3
September 8 2010
********************************
Enter beginning odometer reading =>
0
Enter ending odometer reading =>
1000
1000
350
Press any key to continue . . .
*/