#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout<< "**********************************"<<endl;
	cout<<"Chibuzo Ononiwu"<<endl;
	cout<<"ID @02627330"<<endl;
	cout<<"SYCS-135 Computer Science I"<<endl;
	cout<<"Lab 3"<<endl;
	cout<<"September 8,2010"<<endl;
	cout<<"***********************************"<<endl<<endl;
	cout<<"AREA CALCULATOR"<<endl<<endl;
	int side;                     // 1.  declare variable to input
    cout << "Enter one side of  the square=> ";        // 2.  prompt the user for input
    cin >> side;                     // 3.  get user input
	cout << "The area is  "<< side*side << endl; // 4.  multiply input by itself
	return 0;                          // return program completed OK to
                                           // the operating system
}

/*
**********************************
Chibuzo Ononiwu
ID @02627330
SYCS-135 Computer Science I
Lab 3
September 8,2010
***********************************

AREA CALCULATOR

Enter one side of  the square=> 23
The area is  529
Press any key to continue . . .
*/