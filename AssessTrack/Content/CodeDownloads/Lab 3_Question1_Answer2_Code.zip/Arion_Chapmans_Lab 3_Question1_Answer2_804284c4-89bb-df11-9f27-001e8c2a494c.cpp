#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
    int area;
	cout << "***************************" << endl;
	cout << "Howard Student" << endl;
	cout << "ID @123456" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 7, 2010" << endl;
	cout << "***************************" << endl;
	cout << " " << endl;
	cout << "AREA CALCULATOR" << endl;
	cout << " " << endl;
	cout << "Enter the number of inches of a side=> ";// 2.  prompt the user for the number of inches
	cin >> area;                     // 3.  get number of inches from user
	cout << " " << endl;
	cout << "The area is " << area*area << endl; // 4.  output message
	return 0;                          // return program completed OK to
                                           // the operating system
}
/****************************
Howard Student
ID @123456
SYCS-135 Computer Science I
Lab 3
September 7, 2010
***************************

AREA CALCULATOR

Enter the number of inches of a side=> 12

The area is 144*/;
