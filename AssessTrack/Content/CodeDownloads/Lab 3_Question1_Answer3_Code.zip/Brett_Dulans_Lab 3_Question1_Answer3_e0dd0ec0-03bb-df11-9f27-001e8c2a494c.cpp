#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
const float RATE = 0.35;
int main()
{
 float beg;
 float end;
 cout << fixed << showpoint;
 cout << "######################## " << endl;   
 cout << "Howard Student " << endl;      // Howard Student
 cout << "SYCS-135 Computer Science I " << endl;   // Computer Science
 cout << "Lab #3 " << endl;
 cout << "September 7, 2010 " << endl;
 cout << "######################## " << endl;
 cout << endl;
 cout << endl;
 cout << " Mileage Reimburstment Calculator " << endl;
 cout << endl;
 cout << "What is your beginning odometer reading --> " ;  //1) prompt user input
 cin >> beg;                                              //2) get user input
 cout << "What is your ending odometer reading --> " ; //1) prompt user input
 cin >> end;            //2) get user input
 cout << setprecision(2)<<"You traveled "<< (end-beg) << "miles. At $0.35 per mile, your reimburstment is $" << (RATE*(end-beg)) << endl;
 //5) output data 
 return 0;
}
//########################
//Howard Student
//SYCS-135 Computer Science I
//Lab #3
//September 7, 2010
//########################

//Mileage Reimburstment Calculator
//What is your beginning odometer reading --> 1200
//What is your ending odometer reading --> 1867
//You traveled 667.00miles. At $0.35 per mile, your reimburstment is $233.45      