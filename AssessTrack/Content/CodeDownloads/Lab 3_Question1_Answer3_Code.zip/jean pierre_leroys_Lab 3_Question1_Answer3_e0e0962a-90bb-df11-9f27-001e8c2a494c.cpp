#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
#include <iomanip>
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << "****************************" << endl;
	cout << "Jean Pierre Leroy" << endl;
	cout << "ID @02647910" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Assignment 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "****************************" << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
	int beginning_number;
	cout << "Enter beginning odometer reading=> " << endl;
	cin >> beginning_number;
	int ending_number;
	cout << "Enter ending odometer reading=> " << endl;
	cin >> ending_number;
	cout << fixed << showpoint;
	cout << "You traveled " << ending_number-beginning_number << " miles. AT $.35 per mile, your reimbursement is $";
	int mileage = (ending_number-beginning_number);
	cout << setprecision(2) << mileage*0.35 << endl;
	return 0;
}
