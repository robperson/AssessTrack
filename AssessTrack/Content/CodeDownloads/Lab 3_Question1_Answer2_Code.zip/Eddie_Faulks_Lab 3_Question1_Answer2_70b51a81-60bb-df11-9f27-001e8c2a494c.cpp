#include <iostream>        
#include <string>          
using namespace std;      

int main()
{
    cout << "***************************" << endl;  
    cout << "Eddie Faulk" << endl;
    cout << "@02652321" << endl;
    cout << "SYCS-135 Computer Science I" << endl;
    cout << "Lab 3" << endl;
    cout << "September 7, 2010" << endl;
    cout << "***************************" << endl << endl;
    cout << "AREA CALCULATOR" << endl << endl;
    int side;  
    int area;
    cout << "Enter the number of inches of a side" << endl;
    cin >>side;
    area=side*side;
    cout << "The area of the square is " << area << endl;
    cout << "Press any key to continue..." << endl;
    return 0;
}
/*
***************************
Eddie Faulk
@02652321
SYCS-135 Computer Science I
Lab 3
September 7, 2010
***************************

AREA CALCULATOR

Enter the number of inches of a side
52
The area of the square is 2704
Press any key to continue...
*/