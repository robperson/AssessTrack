#include <iostream>                        // include input/output library code
#include <iomanip>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
        int begin_odometer, ending_odometer; 
		float true_odometer;                     
        cout << "**********************" <<endl;        
        cout << "Howard Student" <<endl;
		cout << "ID @02598115" <<endl;
		cout << "SYCS-135 Computer Science I" <<endl;
		cout << "Assignment 3" <<endl;
		cout << "September 7, 2010" <<endl;
		cout << "**********************" <<endl;
		cout <<endl;
		cout << "MILEAGE REIMBURSEMENT CALCULATOR" <<endl;
		cout <<endl;
		cout << "Enter the beginning odometer reading => ";
		cin >> begin_odometer;
		cout <<endl;
		cout << "Enter the ending odometer reading => ";
		cin >> ending_odometer;
		true_odometer = (ending_odometer - begin_odometer);
		cout << fixed << showpoint;
		cout <<endl;
		cout <<  "You traveled " << setprecision(2) << true_odometer << " miles.  At $.35 per mile, your reimbursement is $" << setprecision(2) << true_odometer * .35 << endl; 
	return 0;    
}
/***********************
Howard Student
ID @02598115
SYCS-135 Computer Science I
Assignment 3
September 7, 2010
**********************

MILEAGE REIMBURSEMENT CALCULATOR

Enter the beginning odometer reading => 55044

Enter the ending odometer reading => 55178

You traveled 134.00 miles.  At $.35 per mile, your reimbursement is $46.90
Press any key to continue . . .*/