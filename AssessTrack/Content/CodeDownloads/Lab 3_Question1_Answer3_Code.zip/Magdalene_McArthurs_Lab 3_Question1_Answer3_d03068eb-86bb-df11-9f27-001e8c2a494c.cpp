#include "stdafx.h"
#include <iostream>
#include <iomanip>
using namespace std;
int main()
{
    cout<<"***************************"<< endl;
    cout<<"Magdalene McArthur"<< endl;
    cout<<"ID @02645775"<< endl;
    cout<<"SYCS-135 Computer Science I"<< endl;
    cout<<"Lab 3"<< endl;
    cout<<"September 8, 2010"<< endl;
    cout<<"***************************"<< endl;
    cout<<"MILEAGE REIMBURSEMENT CALCULATOR"<< endl;

float begginning, ending, mileage, reimbursement;
cout << "Enter begginning odometer reading=> " << endl;  //prompt user input
cin >> begginning;										 //get user input
cout << "Enter ending odometer reading=> " << endl;	//prompt user input
cin >> ending;										   //get user input
const float rate = .35;							
mileage = ending - begginning;						//subtract ending input from begginning input	
cout << fixed << showpoint<< setprecision(2) << "You traveled " << mileage /*output data*/ << " at $.35 per mile, your reimbursement is $" << rate*mileage /*multiply difference by .35*/ << endl; /*output data*/
return 0;
/* ****************************
Magdalene McArthur
ID @02645775
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***************************
MILEAGE REIMBURSEMENT CALCULATOR
Enter begginning odometer reading=>
55044
Enter ending odometer reading=>
55178
You traveled 134.00 at $.35 per mile, your reimbursement is $46.90
Press any key to continue . . . */

}


