#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout<<"***************************"<<endl;
	cout<<"Howard Student" <<endl;
	cout<<"ID @123456"<<endl;
	cout<<"SYCS-135 Computer Science I"<<endl;
	cout<<"Lab 3"<<endl;
	cout<<"September 7, 2010"<<endl;
	cout<<"***************************"<<endl;
	cout<<"";
	cout<<"AREA CALCULATOR"<<endl;
	cout<<"";
	int side;
	cout<<"Enter one side of the square=> "<<endl;
	cin>> side;
	cout<<"The area is " << side * side << endl;
	return 0;
}
/****************************
Howard Student
ID @123456
SYCS-135 Computer Science I
Lab 3
September 7, 2010
***************************
AREA CALCULATOR
Enter one side of the square=>
12
The area is 144
Press any key to continue . . .*/