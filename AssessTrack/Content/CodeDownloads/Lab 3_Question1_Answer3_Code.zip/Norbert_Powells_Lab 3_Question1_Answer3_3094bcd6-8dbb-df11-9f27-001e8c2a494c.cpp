#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main()
{
	cout << "****************************\nHoward Student\nID 02642070\nSYCS-135 Computer Science I\nLab 3\nSeptember 8, 2010\n****************************\n\n";
	cout << "MILEAGE REIMBURSEMENT CALCULATOR\n\n"; 
	cout << "Enter beginning odometer reading ";//1) prompt user input
	float begin;
	cin >> begin;//2) get user input
	cout << endl << "Enter ending odometer reading ";//1) prompt user input
	float end;
	cin>> end;//2) get user input
	float traveled= end-begin;//3) subtract ending input from beginning input
	float reimbursement=.35*traveled;//4) multiply difference by .35
	cout << fixed << showpoint;
	cout << endl << setprecision(2) << "You traveled " <<traveled<<" miles.";//5) output data 
	cout << " At $.35 per mile, your reimbrusement is " <<reimbursement << endl <<endl;//5) output data	
	system("pause");
	return 0;
	/*****************************
Howard Student
ID 02642070
SYCS-135 Computer Science I
Lab 3
September 8, 2010
****************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading 51.23

Enter ending odometer reading 60.00

You traveled 8.8 miles. At $.35 per mile, your reimbrusement is 3.1

Press any key to continue . . .*/
}


