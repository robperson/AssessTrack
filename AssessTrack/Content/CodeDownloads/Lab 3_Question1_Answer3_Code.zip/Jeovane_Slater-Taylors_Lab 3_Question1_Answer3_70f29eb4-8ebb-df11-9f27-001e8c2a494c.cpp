#include <iostream>										// include input/output library code
#include <string>										// include string manipulate library code
#include <iomanip>										// allows all of the names in a namespace
using namespace std;									// to be accessed without the namespace
														// identifier as a qualifier
											

int main()
{		float start;										// allows user to input a number
		float end;
        cout << "***************************" << endl;
		cout << "Jeovane Slater-Taylor" << endl;			// identifies user name
        cout << "ID @02642186" << endl;						// identifies user id number
		cout << "SYCS-135 Computer Science 1" << endl;		// identifies course/course number
		cout << "Lab 3" << endl;							// identifies assignment name
		cout << "September 8, 2010" << endl;				// identifies date
		cout << "***************************" << endl;
		cout << "  " << endl;								// adds a space
		cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
		cout << "  " << endl;
		cout << "Enter beginning odometer reading=> ";		// prompts user to input a number
		cin >> start;										// outputs a number
		cout << "  " << endl;
		cout << "Enter ending odometer reading=> ";			// prompts user to input a number
		cin >> end;											// outputs a number
		cout << " " << endl;
		cout << fixed << showpoint;
		cout << setprecision(2) << "You traveled " << end-start << " miles. At $.35 per mile, your reimbursement is $" << (end-start)*.35 << endl;	// produces the number of miles driven and cost of reimbursement
		cout << "  " << endl;
		system("pause");					
		return 0;					 							
											
}        
   
//***************************
Jeovane Slater-Taylor
ID @02642186
SYCS-135 Computer Science 1
Lab 3
September 8, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044

Enter ending odometer reading=> 55178

You traveled 134.00 miles. At $.35 per mile, your reimbursement is $46.90

Press any key to continue . . .     