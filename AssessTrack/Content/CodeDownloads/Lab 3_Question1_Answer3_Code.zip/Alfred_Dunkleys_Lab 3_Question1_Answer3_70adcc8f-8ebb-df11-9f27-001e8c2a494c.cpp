#include <iostream>                        // include input/output library code
#include <string>  
#include <iomanip>						   // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	
	cout << "******************************* \n";
	cout << "Alfred Dunkley \n"; // studnets name
	cout << "ID @02644062 \n"; // studnets Id number
	cout << "SYCS-135 Computer Science 1 \n"; // course or subject
	cout << "Lab 3 \n"; // assignment 
	cout << "September 7, 2010 \n";
	cout << "******************************* \n\n";
	cout << " MILAGE REIMBURSEMENT CALCULATOR \n\n"; // topic
	float beginning;
	cout << "Enter beginning odometer reading: "; // enter odometer at beginning
	cin >> beginning; 
	float ending;
	cout << "\nEnter ending odometr reading "; // enter value of odometer at ending
	cin >> ending;
	float reimbursement;
	reimbursement= ending- beginning; // calculate reimbursement
	cout << fixed << showpoint;
	cout << setprecision(2)<< "\nYou traveled "<<reimbursement<<" miles. At .35 per mile, your reimbursement is $ "<<reimbursement * .35<<endl<<endl; // calculate your refund
return 0;  
}
/********************************
Alfred Dunkley
ID @02644062
SYCS-135 Computer Science 1
Lab 3
September 7, 2010
*******************************

 MILAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading: 55044

Enter ending odometr reading 55178

You traveled 134.00 miles. At .35 per mile, your reimbursement is $ 46.90

Press any key to continue . . .*/