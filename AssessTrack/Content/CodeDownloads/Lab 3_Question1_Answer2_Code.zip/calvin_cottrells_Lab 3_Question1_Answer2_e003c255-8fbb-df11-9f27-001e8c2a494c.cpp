#include <iostream>					// include input/output library code
using namespace std;					// allows all of the names in a namespace
							// to be accessed without the namespace
							// identifier as a qualifier
int main ()
{
	int square;									// get the square of a number
	int area;									// get the area of a number
	cout << "****************************" << endl;					// indentfication of program creator
	cout << "Calvin Cottrell" << endl;						// name
	cout << "ID @02653347" << endl;							// id number
	cout << "SYCS-135 Computer Science I" << endl;					// course 
	cout << "Lab 3" << endl;							// lab number
	cout << "September 8, 2010" << endl;						// date
	cout << "***************************" << endl;
	cout << endl;							// new line
	cout << "AREA CALCULATOR" << endl;				// title
	cout << endl;							// new line
	cout << "Enter one side of square => " ;			// prompt user to enter length of one side of square
	cin >> square;							// output number
	cout << endl;							// new line
	area = (square * square);					// calculate area of given number
	cout << "The area of the square is " << area <<endl; // show user the area of the number they have given 
	system ("pause");					        // pause system
	return 0;							// return system 
}
// ****************************
// Calvin Cottrell
// ID @02653347
// SYCS-135 Computer Science I
// Lab 3
// September 8, 2010
// ***************************
//
// AREA CALCULATOR
//
// Enter one side of square => 4
//
// The area of the square is 16
// Press any key to continue . . .