                 
#include <string> 
#include <iostream> 
#include <iomanip>
using namespace std;
int main()
{
		
        int Before;
		int After;
		int Dif;
        cout << "Gattis' Mileage Calculator ™  "<<endl;
		cout<< "Enter The Original Odometer Reading "<<endl;
		cin >> Before;
		cout<< "Enter The Odometer Reading After Driving "<<endl;
        cin >> After; 
		Dif = After - Before ;
	 	cout << fixed << showpoint;
		cout << setprecision(2) << " You Drove " << Dif << "miles. At $.35, You should recieve $ " << Dif * .35 << "in compensation"<<endl; 
		cout<<" I Hope You Get Your Money! =] ";
		string finish;
		cin >> finish;
	return 0;
}

//Gattis' Mileage Calculator Ö
//Enter The Original Odometer Reading
//500
//Enter The Odometer Reading After Driving
//800
 //You Drove 300miles. At $.35, You should recieve $ 105.00in //compensation
// I Hope You Get Your Money! =]


