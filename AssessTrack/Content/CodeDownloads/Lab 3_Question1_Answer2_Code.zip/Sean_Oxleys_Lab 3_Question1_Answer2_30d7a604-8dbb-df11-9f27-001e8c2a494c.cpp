#include <iostream>
#include <string>
using namespace std;

int main()
{
	int number; 
	cout << "************* \n Sean Oxley \n ID @02645814 \n SYCS-135 Computer Science I \n Lab 3 \n Sept 8, 2010 \n************* " << endl << endl;
	cout << "Area Calculator" << endl << endl;
	
	cout << "Enter one side of the square=>" << endl;
	cin >> number;
	cout << "The area is " << number*number << endl;
	return 0;
}

// Enter one side of the square=> 12
// The area is 144      