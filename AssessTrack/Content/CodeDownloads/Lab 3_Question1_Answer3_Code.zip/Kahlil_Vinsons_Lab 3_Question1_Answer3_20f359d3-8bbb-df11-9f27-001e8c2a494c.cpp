#include <iostream> 
#include <iomanip>
using namespace std; 
 

int main() 
{
	cout << "***************************" << endl;		
	cout << "Kahlil Vinson" << endl; 
	cout << "ID @02641830" << endl; 
	cout << "sycs-135 computer science I" << endl; 
	cout << "Lab 3" << endl; 
	cout << "September 7, 2010" << endl; 
	cout << "***************************" << endl << endl; 
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl; 
	float beginning_odometer_reading;
	float ending_odometer_reading;
	float reimbursment;	
	cout << "enter beginning_odometer_reading ";   //prompt user input	
	cin >> beginning_odometer_reading;				//get user input
	cout << "enter ending_odometer_reading ";		//prompt user input
	cin >> ending_odometer_reading;					//get user input
	cout << "You traveled 134.00 mile at ";
	cout << "At $.35 per mile your reimbursment is ";
	cout << fixed << showpoint;

	reimbursment = ending_odometer_reading - beginning_odometer_reading; //subtract ending input from beginning input
	cout << "At $.35 per mile your reimbursment is " << reimbursment * .35 << endl;	//multiply difference by .35
	return 0;	
													/****************************
													Kahlil Vinson
													ID @02641830
													sycs-135 computer science I
													Lab 3
													September 7, 2010
													***************************

													MILEAGE REIMBURSEMENT CALCULATOR

													enter beginning_odometer_reading 55044
													enter ending_odometer_reading 55178
													You traveled 134.00 mile at At $.35 per mile your reimbursment is At $.35 per mile your reimbursment is 46.900000
													Press any key to continue . . .*/ 
}
												
												        