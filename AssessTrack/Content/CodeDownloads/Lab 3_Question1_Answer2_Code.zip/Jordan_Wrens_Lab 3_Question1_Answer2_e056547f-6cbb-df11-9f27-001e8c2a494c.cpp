#include <iostream>

using namespace std;


int main()
{ 
  cout << "AREA CALCULATOR" << endl;
  cout << endl;
  int number;
  cout << "Enter one side of the square =>";
  cin >> number;
  cout << endl;
  cout << "The Area is " << number*number << endl;
  cout << "Press any key to continue..." << endl;
  return 0;
}
  
        