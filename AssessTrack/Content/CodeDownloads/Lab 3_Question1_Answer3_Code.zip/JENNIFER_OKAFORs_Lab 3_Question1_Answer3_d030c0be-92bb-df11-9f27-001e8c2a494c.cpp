#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
#include <iomanip>
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
		cout << "*********************************" <<endl;	//output message
       cout << "Jennifer Okafor" << endl;					//output message
	   cout << "ID @02624575" <<endl;						//output message
	   cout << "SYCS-135 Computer Science I" <<endl;		//ouput message
	   cout << "Assignment 3"<<endl;						//output message
	   cout << "September 7, 2010"<<endl;					//output message
	   cout << "**********************************"<<endl<<endl;	//output message
	   cout << "MILEAGE REIMBURSEMENT CALCULATOR"<<endl;	//output message
	   float beginning;										//declare variable to store beginning odometer reading
	   float ending;										//declare variable to store ending odometer reading
	   float difference;									//declare variable to store difference of beginning and ending reading
	   cout << "\nEnter beginning odometer reading=> ";		//output message
	   cin >> beginning;									//get begininning odometer reading from user
	   cout << "\n";										//output message
	   cout << "Enter ending odometer reading=> ";			//output message
	   cin >> ending;										//get ending odometer reading fro user
	   difference = ending-beginning;
	   cout << "\n";										//output message
		cout << "You have traveled "<< difference;			//output message
		cout << " miles.";									//output message
		cout << fixed << showpoint;
		cout << setprecision(2) << "  At $.35 per mile, your reimbursement is $"<< difference*.35;
		cout << "." <<endl;									//output message
		cout << "\n";										//output message
		return 0;											//return program completed  OK to the operating system

}
/**********************************
Jennifer Okafor
ID @02624575
SYCS-135 Computer Science I
Assignment 3
September 7, 2010
**********************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044

Enter ending odometer reading=> 55178

You have traveled 134 miles.  At $.35 per mile, your reimbursement is $46.90.

Press any key to continue . . .
*/