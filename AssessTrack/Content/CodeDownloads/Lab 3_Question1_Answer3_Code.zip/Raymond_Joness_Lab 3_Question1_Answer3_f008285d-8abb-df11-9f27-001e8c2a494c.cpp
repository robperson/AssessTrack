#include<iostream>//for cout, endl
#include<string>
#include<iomanip>
using namespace std;

	int main()
{
	const string line = "***************************";//Border
	cout << line << endl;
	cout << "Howard University" << endl;
	cout << "ID @123456" << endl;
	cout << "SYCS-135 Computer Science I" <<endl;
	cout << "Lab 3" << endl;
	cout << "September 7, 2010" << endl;
	cout << line << endl << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
	cout << fixed << showpoint;
	float number;//beginning odometer reading
	float odometer;//ending odometer reading
	cout << "Enter beginning odometer reading=> ";
	cin >> number;
	cout << endl << endl;
	cout << "Enter ending odometer reading=> ";
	cin >> odometer;
	cout << endl << endl;
	float miles = odometer - number;//number of miles
	float reimbursement = .35 * miles; //reimbursement
	cout << "You traveled " << miles << " miles.";
	cout << setprecision(2) << " At $.35 per mile, your reimbursement is " << reimbursement << "." << endl;
	system("pause");
	return 0;
}