#include <iostream>   //Include standard input and output files.
#include  <string>    //Includes the string llibrary code.
#include <iomanip>    //Includes the ouotput of float values.
using namespace std;  //Use namespaces in standard llibrary.
int main()            //main Function.
{
	float beginningmileage;
	float endingmileage;
	cout << "********************************************* \n";
	cout << "Howard Student \n";
	cout << "ID - @02647499 \n";
	cout << "SYCS-135 Computer Science I \n";
	cout << "Assignment 3\n";
	cout << "September 08, 2010 \n";
	cout << "********************************************* \n";

	cout << "\n";
	cout << "MILEAGE REIMBURSEMENT CALCULATOR \n";     //Stating the meaning and function of the code.
	cout << "\n";
	cout << "Enter beginning odometer reading => ";    //Prompting the user to enter beginning mileage.
	cin >> beginningmileage;
	cout << "\n";
	cout << "Enter ending odometer reading => ";       //Prompting user to enter ending mileage.
	cin >> endingmileage;
	cout << "\n";
	cout << fixed << showpoint;
	cout << setprecision(2)<< "You traveled " << endingmileage - beginningmileage << ". " << "At $.35 per mile, your reimbursement is $" << (endingmileage - beginningmileage) * .35 << ".\n";    //Reimbursement is calculated and answer is shown on the screen.
	cout << "\n";
	return 0;
	/*	*********************************************
		Howard Student
		ID - @02647499
		SYCS-135 Computer Science I
		Assignment 3
		September 08, 2010
		*********************************************

		MILEAGE REIMBURSEMENT CALCULATOR

		Enter beginning odometer reading => 55044

		Enter ending odometer reading => 55178

		You traveled 134.00. At $.35 per mile, your reimbursement is $46.90.

		Press any key to continue . . .*/
}
