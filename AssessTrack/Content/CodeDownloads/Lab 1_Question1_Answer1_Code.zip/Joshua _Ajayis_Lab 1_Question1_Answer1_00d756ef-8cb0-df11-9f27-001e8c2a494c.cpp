#include <iostream>
using namespace std;
int main ()
{
	cout << "hello world, message from the great Joshua Ajayi" << endl;
	return 0;
}
//hello world