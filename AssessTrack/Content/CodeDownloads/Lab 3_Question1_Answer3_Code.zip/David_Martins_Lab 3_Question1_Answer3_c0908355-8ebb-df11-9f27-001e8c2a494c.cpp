#include <iostream>   // include input/output library code
#include <string>    // include string manipulate library code
#include <iomanip>  // required for output of float values
using namespace std;// allows all of the names in a namespace 
        // to be accessed without the namespace 
        // identifier as a qualifier
int main()
{
	string myname;
	cout << "***************************" << endl;
	cout << "Howard Student" << endl;
	cout << "ID @123456" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Assignment 3" << endl;
	cout << "September 7, 2010" << endl;
	cout << "***************************" << endl << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
	float miles; // 1.  declare variable to store reading on odometer
	float ending;
	float beginning;
	float reimbursement;
	cout << fixed << showpoint;
	cout << "Enter beginning odometer reading=> ";
	cin >> beginning;
	cout << " " << endl << endl;
	cout << "Enter ending odometer reading=> ";	// 2.  prompt the user for the beginning odometer reading
	cin >> ending;	// 3.  get length from user
	miles = ending - beginning;
	reimbursement = miles * .35;
	cout << " " << endl;
	cout << setprecision(2)<< "You traveled "	<< miles<<"miles. "; // 4.  output data
	cout <<"At $.35 per mile, your reimbursement is " << reimbursement;
	cout << " " << endl;
	system ("pause");
	return 0; // return program completed OK to// the operating system								
}
/*
***************************
Howard Student
ID @123456
SYCS-135 Computer Science I
Assignment 3
September 7, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044


Enter ending odometer reading=> 55178

You traveled 134.00. At $.35 per mile, your reimbursement is $46.90.
Press any key to continue . . . */;
        