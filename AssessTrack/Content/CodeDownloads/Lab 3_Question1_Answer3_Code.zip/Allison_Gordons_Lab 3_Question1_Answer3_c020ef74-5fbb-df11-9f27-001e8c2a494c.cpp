#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
#include <iomanip>                         // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
        cout <<"Allison Gordon" << endl;
  cout <<"ID @02633009"<< endl;
  cout <<"SYCS-135-Computer Science I"<<endl;
  cout <<"Lab 3"<<endl;
  cout <<"September 7,2010"<<endl;
  cout <<"******************************************************"<<endl;
  cout <<""<< endl;
  cout << "MILEAGE REIMBURSEMENT CALCULATOR"<< endl;
  cout << ""<< endl;
  cout << fixed << showpoint;
  float beginning_reading;
  float ending_reading;           // 1. prompt user input
  float  answer;
  float  reimbursement;  
  cout << "Enter beginning odmeter reading=> ";              // 2. get user input
  cin >> beginning_reading;  
  cout << "Enter ending odmeter reading=>" ;
  cin >> ending_reading;
  answer= ending_reading - beginning_reading;     // 3.subtract ending input from beginning output
  cout << setprecision(2)<< " You traveled " << answer << " miles "; 
  reimbursement = answer * 35;        // 4. multiply difference by .35 
  cout << setprecision(2)<< " At $.35 per mile, your reimbursement is $46.90.";
  return 0;                          // return program completed OK to
                                           // the operating system
}


//Allison Gordon
//ID @02633009
//SYCS-135-Computer Science I
//Lab 3
//September 7,2010
//******************************************************

//MILEAGE REIMBURSEMENT CALCULATOR

//Enter beginning odmeter reading=> 5504
//Enter ending odmeter reading=>55178
//You traveled 49674.00 miles  At $.35 per mile, your reimbursement is $46.90.
//Press any key to continue . . .