#include <iostream>
#include <string>
using namespace std;
int main()
{
 cout << "*************************** " << endl; // Display line of stars
 cout << "Howard Student " << endl; // Display "Howard Student"
 cout << "ID @02626082 " << endl; // Display ID#
 cout << "SYCS-135 Computer Science I " << endl; // Display "SYCS-135 Computer Science I"
 cout << "Lab 3 " << endl; // Display "Lab 3"
 cout << "September 7, 2010 " << endl; // Display "September 7, 2010"
 cout << "*************************** " << endl; // Display line of stars
 cout << endl; // end line / skip line
 cout << "AREA CALCULATOR" << endl; // Display "AREA CALCULATOR"
 int side; // Declare variable to store integer
 cout << "Enter the number of inches of a side => " ; // Prompt user for side of square
 cin >> side; // get integer from user
 cout << "The area of the square is " << side*side << endl; // output message
 return 0; // return program completed OK
// to the operating system
//***************************
//Howard Student
//ID @02626082
//SYCS-135 Computer Science I
//Lab 3
//September 7, 2010
//***************************
//
//AREA CALCULATOR
//Enter the number of inches of a side => 12
//The area of the square is 144
}