#include <iostream>             // include input/output library code
#include <string>               // include string manipulate library code
using namespace std;            // allows all of the names in a namespace
                                // to be accessed without the namespace 
                                // identifier as a qualifier
int main()
{
   //delclares variables
   float inches, area;
   cout << "****************************\n";
   cout << "Jonathan Young\n";
   cout << "@02576822\n";
   cout << "SYCS-135 Computer Science 1\n";
   cout << "Lab 3\n";
   cout << "September 7, 2010\n";
   cout << "****************************\n\n";
   cout << "AREA CALCULATOR\n\n";
   //prompts and retrieves data from user
   cout << "Enter number of inches of a side=> ";
   cin >> inches;
   //calculates the area of a square
   area = inches * inches;
   cout << "\nThe area is " << area << endl; //outputs message
   return 0; 
}


/****************************
Jonathan Young
@02576822
SYCS-135 Computer Science 1
Lab 3
September 7, 2010
****************************

AREA CALCULATOR

Enter number of inches of a side=> 8

The area is 64
Press any key to continue . . .*/
        