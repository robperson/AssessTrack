#include <iostream> // include input/output library code 
#include <iomanip> // include iomanip library code 
using namespace std;  // allows all of the names in a namespace to be accessed without the namespace  
					// identifier as a qualifier 
int main() // Calculate number of miles travelled and reimbursement for salesperson
{
	float orig; // create a variable to store beginning input
	float fina; // create a variable to store ending input
	float diffe; // create a variable for difference 
	float price;
	cout << "***************************"<< endl; // Enter stars
	cout << "Jeremy Blackstone" << endl; // Enter name
	cout << "ID @02643836" << endl; // Enter ID number
	cout << "SYCS-135 Computer Science I" << endl; // Enter course
	cout << "Assignment 3" << endl; // Enter lab number
	cout << "September 8, 2010" << endl; // Enter date
	cout << "***************************" << endl << endl; // Enter stars
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl; // Enter name of program
	cout << fixed << showpoint;
	cout << "Enter beginning odometer reading=> ";  // receive original odometer reading from user
	cin >> orig; // store original odometer reading in original
	cout << "Enter ending odometer reading=> "; // receive final odometer reading from user
	cin >> fina; // store final odometer reading in final
	diffe = orig - fina; // calculate miles travelled
	price = diffe * 0.35; // calculate reimbursment
	cout << fixed << showpoint;
	cout << setprecision(2)<< "You traveled " << diffe << " miles. At $.35 per mile, your reimbursement is $" << price << endl; // output data to user
	return 0; // return program completed OK to the operating system
}
/* ***************************
Jeremy Blackstone
ID @02643836
SYCS-135 Computer Science I
Assignment 3
September 8, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 50000
Enter ending odometer reading=> 48520
You traveled 1480.00 miles. At $.35 per mile, your reimbursement is $518.00
Press any key to continue . . .*/ 



        