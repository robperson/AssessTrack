
    #include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
#include <iomanip>
using namespace std;                       // allows all of the names in a namespace to be accessed without the namespace // identifier as a qualifier

int main()
{
  cout << "***********************" << endl;
                cout << "Brittany Jackson" << endl;            
  cout << "ID @02605575" << endl;
  cout << "SYCS-135 Computer Science" << endl;
  cout << "Lab 3" << endl;
  cout << "September 7, 2010" << endl;
  cout << "************************" << endl;
                cout << " " << endl;
  cout << "Mileage Reimbursement Calculator" << endl;
  cout << " " << endl;
  cout << fixed << showpoint;
  float beg_reading;                      // 1. Declare variable to beginning reading 
  float end_reading;          // 2. Declare variable to ending reading  
  float answer;           // 3. Declare variable to answer
  float reimbursement;         // 4. Declare variable as reimbursement
        cout << "Enter beginning odometer reading=> ";   // 5. Prompt the user for the beginning reading
  cin >> beg_reading;             // 6. Get beginning reading from user 
  cout << "Enter ending odometer reading=> ";    // 7. Prompt the user for the ending reading 
  cin >> end_reading;          // 8. Get the ending reading from user 
  answer = end_reading - beg_reading;      // 9. Subtract end from beginning 
  cout << setprecision(2)<< "You traveled " << answer << " miles.";      // 10. Ouput message
  reimbursement = answer * .35;             // 11. Multiple output by .35
  cout << setprecision(2)<< " At $.35 per mile, your reimbursement is $" << reimbursement << endl; // 12. Output
  
    return 0;                                                  // return program completed OK to
                                                                   // the operating system
}
//***********************
//Brittany Jackson
//ID @02605575
//SYCS-135 Computer Science
//Lab 3
//September 7, 2010
//************************
//Mileage Reimbursement Calculator
//Enter beginning odometer reading=> 55044
//Enter ending odometer reading=> 55178
//You traveled 134.00 miles. At $.35 per mile, your reimbursement is $46.90
//Press any key to continue . . .       