
#include <iostream>
using namespace std;
int main()
{
cout<<"Hello World" <<endl;
	return 0;
}
Hello World
Press any key to continue . . .
'helloworld.exe': Loaded 'C:\Documents and Settings\student\My Documents\Visual Studio 2008\Projects\helloworld\Debug\helloworld.exe', Symbols loaded.
'helloworld.exe': Loaded 'C:\WINDOWS\system32\ntdll.dll'
'helloworld.exe': Loaded 'C:\WINDOWS\system32\kernel32.dll'
'helloworld.exe': Loaded 'C:\WINDOWS\WinSxS\x86_Microsoft.VC90.DebugCRT_1fc8b3b9a1e18e3b_9.0.30729.1_x-ww_f863c71f\msvcp90d.dll'
'helloworld.exe': Loaded 'C:\WINDOWS\WinSxS\x86_Microsoft.VC90.DebugCRT_1fc8b3b9a1e18e3b_9.0.30729.1_x-ww_f863c71f\msvcr90d.dll'
The program '[3804] helloworld.exe: Native' has exited with code 0 (0x0).
       