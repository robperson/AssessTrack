/* Hana Nelson 
ID @02575836
SYCS-135 Computer Science 1 
Lab 3 
September 8, 2010*/ 

#include <iostream>                        // include input/output library code
#include <string>						   // include string manipulate library code
#include <iomanip>						// include to have two decimal places 
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier
int main()
{
	float odometer1,odometer2,reimbursment;			           //declare variable 
	cout <<fixed << showpoint;						// prompt user for float numbers 
	cout << "Enter beginning odometer reading=> ";//prompt user input 
	cin >> odometer1;							//get user input 
	cout << "Enter ending odometer reading=> "; //prompt user input
	cin >> odometer2;							//get user input 
	reimbursment =(odometer2-odometer1)*.35;    // subtract ending input from beginning input and mutliply difference by $.35 
	cout <<showpoint << setprecision(2)<< "You traveled "<<(odometer2-odometer1)<< "miles. At $.35 per mile, your reimbursment is $" << reimbursment<<"."<<endl; //output data  
	cin >> odometer2;
	return 0;							   //return program completed OK to 
										   //the operating system
}
//Enter beginning odometer reading=> 5000
//Enter ending odometer reading=> 6000
//You traveled 1000.00miles. At $.35 per mile, your reimbursment is $350.00.