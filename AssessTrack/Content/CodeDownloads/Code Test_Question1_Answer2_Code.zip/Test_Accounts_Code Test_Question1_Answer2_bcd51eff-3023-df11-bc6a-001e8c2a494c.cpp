#include <iostream>
using namespace std;
void main()
{
while(true){cout<<"adkdhkdfjd"<<endl;}
}
        