#include <iostream>
#include <string>
using namespace std;
int main()
{
int side; //Declare the side
cout << "######################## " << endl;
cout << "Howard Student " << endl; // Howard Student
cout << "SYCS-135 Computer Science I " << endl; // Computer Science
cout << "Lab #3 " << endl;
cout << "September 7, 2010 " << endl;
cout << "######################## " << endl;
cout << endl;
cout << "AREA CALCULATOR! " << endl;
cout << "Enter the side length for the square.. " ; // Ask for number of sides
cin >> side; // Imput number of sides
int area = (side*side);
cout << " And the area is.. " << area << endl; // Output of area
return 0;
}
//########################
//Howard Student
//SYCS-135 Computer Science I
//Lab #3
//September 7, 2010
//########################
//AREA CALCULATOR!
//Enter the side length for the square..17
//And the area is.. 289