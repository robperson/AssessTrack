#include <iostream>      // include input/output library code
using namespace std;     // allows all of the names in a namespace
                         // to be accessed without the namespace
                         // identifier as a qualifier

int main ()
{				
	cout << "***********************" << endl;// heading of the program
	cout << "Cecily Gomes" << endl;                   // Howard Student
	cout << "ID @02652983" << endl;                   // student ID number
	cout << "SYCS-135 Computer Science I" << endl;    // class
	cout << "Assignment 3 " << endl;                         // assignment
	cout << "September 8, 2010" << endl;              // date
	cout << "***********************" << endl << endl;                  
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl; // 1. name of the program
	float begin;                                  // 2. declare variable to store inches
	cout << endl <<"Enter beginning odometer reading "; // 3. prompt the user for the number of miles to start with
	cin >> begin;                               // 4. get number of miles the user began traveling with 
    cout << endl << "Enter ending odometer reading "; // 5. prompt the user for the number of miles at end
	float end;                               // 6. declare end as a decimal 
	cin >> end;								// 7. get the number of miles the user finished traveling with
    float traveled = end - begin;             // 8. declare teh miles traveled as a decimal
	float rate = traveled * .35;             // 9. calculate the reimbursement.
	cout << endl << "You traveled " << traveled;  // 10. the number of miles that you traveled
	cout << " At $.35 per mile, your reimbursement is " << rate << endl << endl; // 11. your reimbursement.
	system ("pause");
	return 0;
}

//***********************
//Cecily Gomes
//ID @02652983 
//SYCS-135 Computer Science I
//Assignment 3
//September 8, 2010
//***********************

        