
       #include <iostream>                        // include input/output library code
#include <string>
#include <iomanip>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << "*****************************************" << endl;
	cout << "Dalonte Parker " << endl;
	cout << "ID @02650202" << endl;
	cout << "SYCS-135 Computer Science I " << endl;
	cout << "Assignment 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "*****************************************" << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
	float reimbursementFactor = 0.35F;
	float reimbursment;
	int begin;//beginning odometer reading
	int end;//ending odometer reading
	int distance;//distance traveled
	cout << "Enter beginning odometer reading=> begin " << endl;
	cin >> begin;
	cout << "Enter ending odometer reading end=> " << endl;
	cin >> end;
	distance=end-begin;
	reimbursment=distance*reimbursementFactor;
	cout << "The distance traveled is distance " << distance << endl;
	cout << "At $.35 per mile, your reimbursement is $" << setprecision(2) <<reimbursment <<endl;
    return 0;
}*****************************************
Dalonte Parker
ID @02650202
SYCS-135 Computer Science I
Assignment 3
September 8, 2010
*****************************************
MILEAGE REIMBURSEMENT CALCULATOR
Enter beginning odometer reading=> begin
1534
Enter ending odometer reading end=>
3674
The distance traveled is distance 2140
At $.35 per mile, your reimbursement is $7.5e+002 