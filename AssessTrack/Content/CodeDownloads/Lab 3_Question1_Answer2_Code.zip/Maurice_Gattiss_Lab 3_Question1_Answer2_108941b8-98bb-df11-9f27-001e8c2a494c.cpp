#include <iostream>                        
#include <string>                         
using namespace std;                      
                                          
                                          

int main()
{
        int side;   
		int area;
        cout << "Enter the length of one side! ";       
        cin >> side;                     
	cout << "The area is" + (side * side) << endl; 
	cout<<" Keep on Working Hard! ";
		string finish;
		cin >> finish;
	return 0;                        
                                         
}
