using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	
	cout << "******************************* \n";
	cout << "Alfred Dunkley \n"; // studnets name
	cout << "ID @02644062 \n"; // studnets Id number
	cout << "SYCS-135 Computer Science 1 \n"; // course or subject
	cout << "Lab 3 \n"; // assignment 
	cout << "September 7, 2010 \n";
	cout << "******************************* \n\n";
	cout << "AREA CALCULATOR \n\n"; // topic
	int number;
	cout << "Enter the number of inches of a side: "; // prompt user input
	cin >> number; //get user input 
	cout << "\nThe area is "<< number * number << "\n"; // multiply input by itself
	return 0;
}
/********************************
Alfred Dunkley
ID @02644062
SYCS-135 Computer Science 1
Lab 3
September 7, 2010
*******************************

AREA CALCULATOR

Enter the number of inches of a side: 12

The area is 144*/