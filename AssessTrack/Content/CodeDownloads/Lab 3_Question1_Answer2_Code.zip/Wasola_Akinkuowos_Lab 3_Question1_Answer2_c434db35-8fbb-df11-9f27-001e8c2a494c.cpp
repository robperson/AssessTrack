#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{	cout << "****************************"<<endl;
	cout << "J.R. Akinkuowo"<<endl; 
	cout << "ID @02641281"<<endl;
	cout << "SYCS-135 Computer Science I"<<endl;
	cout << "Lab 3"<<endl;
	cout << "September 7, 2010"<<endl;
	cout << "****************************"<<endl<<endl;

	cout << "AREA CALCULATOR"<<endl<<endl;

	int number;
	cout << "Enter the number of inches of a side=> "; // prompt user input
	cin >> number; // get user input
	cout << endl << "The area is "<<number*number<<endl; // multiply input by itself
	return 0; // output data          

}

/*****************************
J.R. Akinkuowo
ID @02641281
SYCS-135 Computer Science I
Lab 3
September 7, 2010
****************************

AREA CALCULATOR 

Enter the number of inches of a side 12 

The area is 144
Press any key to continue . . .*/


