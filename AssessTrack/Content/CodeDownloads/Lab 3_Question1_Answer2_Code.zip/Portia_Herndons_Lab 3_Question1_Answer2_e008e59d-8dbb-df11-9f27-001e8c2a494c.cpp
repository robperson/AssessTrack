#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << "********************************" << endl;
	cout << "Portia Herndon" << endl;
	cout << "ID @02643112" << endl;
	cout << "SYCS-135 Computer Science 1" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "********************************" << endl <<endl; 
	cout << "AREA CALCULATOR" << endl << endl;
	int number; 
	cout << "Enter one side of the square=>" << endl;
	cin >> number; 
cout << "The area is " << number*number << endl;      
}
//********************************
//Portia Herndon
//ID @02643112
//SYCS-135 Computer Science 1
//Lab 3
//September 8, 2010
//********************************

//AREA CALCULATOR

//Enter one side of the square=>
//12
//The area is 144 