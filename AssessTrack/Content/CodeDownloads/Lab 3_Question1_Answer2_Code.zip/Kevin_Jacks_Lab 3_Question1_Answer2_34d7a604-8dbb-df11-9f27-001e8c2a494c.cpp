#include <iostream>                        
#include <string>                          
using namespace std;                       
                                      
int main()
{
    int side;                     
    cout << "*************************** "<< endl;//1) prompt user input
	cout << "Howard Student "<< endl;//2) get user input
	cout << "ID @123456 "<< endl;//3) multiply input by itself
	cout << "SYCS-135 Computer Science I "<< endl;//4) output data 
	cout << "Lab 3 "<< endl;
	cout << "September 7, 2010 "<< endl;
	cout << "***************************  \n\n";
	cout << "AREA CALCULATOR \n\n";
	cout << "Enter the number of inches of a side=> "; 
    cin  >> side;
	cout << "The area is "<< side*side<< endl;
	system ("pause");
	return 0;
}
