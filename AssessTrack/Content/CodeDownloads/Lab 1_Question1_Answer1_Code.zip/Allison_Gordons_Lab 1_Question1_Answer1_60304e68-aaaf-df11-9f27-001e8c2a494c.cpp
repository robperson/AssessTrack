#include <iostream>
using namespace std;
int main()
{
	cout<<"Hello Ally"<<endl;
	return 0; 
}

//Hello Ally