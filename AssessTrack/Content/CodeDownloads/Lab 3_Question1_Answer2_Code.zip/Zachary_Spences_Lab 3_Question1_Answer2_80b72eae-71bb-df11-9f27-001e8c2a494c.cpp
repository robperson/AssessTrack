#include <iostream> 
#include <string> 
using namespace std; 
int main()
{
cout<< "****************** "<< endl; 
cout<< "Zachary Spence "<< endl; 
cout<< "ID @02653782 "<< endl; 
cout<< "SYCS - 135 Computer Science I "<< endl; 
cout<< "Lab 3 "<< endl; 
cout<< "September 8 2010 "<< endl; 
cout<< "****************** "<< endl; 
int toSquare; 
cout << "AREA CALC "<<endl; 
cout<< "Enter the length of a side: "<<endl; 
cin >> toSquare; 
toSquare = toSquare * toSquare;
cout << "The Area is " << toSquare << endl; 
return 0; 
}
/*
******************
Zachary Spence
ID @02653782
SYCS - 135 Computer Science I
Lab 3
September 8 2010
******************
AREA CALC
Enter the length of a side:
4
The Area is 16
Press any key to continue . . .
*/