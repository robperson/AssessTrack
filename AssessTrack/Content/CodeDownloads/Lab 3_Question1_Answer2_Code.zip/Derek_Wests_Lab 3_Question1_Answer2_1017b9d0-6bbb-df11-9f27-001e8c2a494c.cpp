#include <iostream>   // include input/output library code
#include <string>  // include string manipulate library code

using namespace std; // allows all of the names in a namespace 
int main()           // to be accessed without the namespace 
                    // identifier as a qualifier
{
	float a = 0;    //initialize a
	float square;   //declare square

	cout << "***********************" << endl; // all this is for the
	cout << "Derek West" << endl;              //heading of the program
    cout << "ID @02653583" << endl;
    cout << "SYCS 135 Computer Science I"<< endl;
	cout << "Lab 3"<< endl;
	cout << "September 7, 2010" << endl;
	cout << "***********************"<< endl<<endl;
	cout << "AREA CALCULATOR"<< endl<<endl;
	
cout << "Enter the number of inches of a side => "; //ask for imput
cin >> a;                                         // chage a's value
square = a*a;                                     // formula for a square's volume
cout << "The area is " << + square << endl; // show answer

	return 0;                       // return program completed OK to
                                           // the operating system
}
/* ***********************
Derek West
ID @02653583
SYCS 135 Computer Science I
Lab 3
September 7, 2010
***********************

AREA CALCULATOR

Enter the number of inches of a side => 12.3
The area is 151.29*/
        