#include<iostream>
#include<string>
using namespace std;
#include <iomanip>

int main() 

{
	   float odb, ode, distance;
	   cout << "*************************" << endl;
	   cout << "Darell Hungerford" << endl;
	   cout << "ID@123456" << endl;
	   cout << "SYCS-135 Computer Science I" <<endl;
	   cout << "Assignment 3" << endl;
	   cout << "September 7, 2010" << endl;
	   cout << "**************************" << endl;
	   cout << "" << endl;
	   cout << "MILEAGE REIMBURSEMENT CALCULATOR"<< endl;
	   cout << "" << endl;
	   cout << "Enter beginning odometer reading => ";
	  
	   cin >> odb; 
	   cout << "" << endl;
	   cout << "Enter ending odometer reading => " ;
	  
	   cin >> ode; 
	   cout << "" << endl;
	   cout << fixed << showpoint;

	   distance = ode-odb;
	   cout << "You traveled " << setprecision(2) << distance << " miles. At $.35 per mile, your reimbursement is " << 0.35 * distance  << endl; 
	   
	   return 0;

}
/*************************
Darell Hungerford
ID@123456
SYCS-135 Computer Science I
Assignment 3
September 7, 2010
**************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading => 55044

Enter ending odometer reading => 55178

You traveled 134.00 miles. At $.35 per mile, your reimbursement is 46.90
Press any key to continue . . .*/

        