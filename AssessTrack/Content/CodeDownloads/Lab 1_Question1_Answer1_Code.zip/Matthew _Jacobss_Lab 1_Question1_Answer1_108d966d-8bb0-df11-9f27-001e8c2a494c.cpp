Paste code here
        #include <iostream>
using namespace std;

int main()
{
	cout << "HelloWorld" << endl;
	return 0;
}