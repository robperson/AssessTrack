#include <iostream>                        // include input/output library code
#include <string>						   // include string manipulate library code 
#include <iomanip> 
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{ 
	cout << "********************************" << endl;
	cout << "Portia Herndon" << endl;
	cout << "ID @02643112" << endl;
	cout << "SYCS-135 Computer Science 1" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "********************************" << endl <<endl; 
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
	int beginning_number; 
	cout << "Enter beginning odometer reading=>" << endl;
	cin >> beginning_number;
	int ending_number; 
	cout << "Enter enging odometer reading=>" << endl; 
	cin >> ending_number; 
	cout << fixed << showpoint; 
	cout << "You traveled " << ending_number-beginning_number << " miles. At $.35 per mile, your reimbursement is $";   
    int mileage = (ending_number-beginning_number); 
	cout << setprecision(2)  << mileage*0.35 << endl;  
}
//********************************
//Portia Herndon
//ID @02643112
//SYCS-135 Computer Science 1
//Lab 3
//September 8, 2010
//********************************

//MILEAGE REIMBURSEMENT CALCULATOR

//Enter beginning odometer reading=>
//55044
//Enter enging odometer reading=>
//55178
//You traveled 134 miles. At $.35 per mile, your reimbursement is $46.90