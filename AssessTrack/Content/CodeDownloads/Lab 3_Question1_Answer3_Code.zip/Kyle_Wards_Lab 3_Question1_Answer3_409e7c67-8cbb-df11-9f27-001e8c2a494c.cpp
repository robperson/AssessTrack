#include <iostream>    // include input/output library code
#include <string>      // include string manipulate library code
#include <iomanip>
using namespace std;   // allows all of the names in a namespace
                       // to be accessed without the namespace
                       // identifier as a qualifier

int main()
{
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl
	<<endl;
	cout << fixed << showpoint;

	
    float amiles;
	float bmiles;
	cout << setprecision(2) << endl<<"Enter beginning odometer reading=> ";       // 2.  prompt the user for their starting number of miles
    cin >> amiles; 										                   // 3.  get start miles from user
	cout << fixed << showpoint; 
	cout << setprecision(2) << endl<<"Enter ending odometer reading=> ";         // 4. prompt the user for their ending number of miles
	cin >> bmiles;														   // 5. get end miles from user
	float tmiles=bmiles-amiles;                                            // 6. total miles equation

	float rate= .35;                                                       // 7. refund rate
	float mback = rate*tmiles;                                             // 8.  equation to calculate refund
	cout << endl<< "You traveled " << tmiles << " miles. " << "At $.35 per mile your reimbursement is $" << mback << "." << endl<<endl;	 // 9.  output message
   	return 0;								                              // return program completed OK to
	

//MILEAGE REIMBURSEMENT CALCULATOR

//Enter beginning odometer reading=> 55044

//Enter ending odometer reading=> 55178

//You traveled 134.00 miles. At $.35 per mile your reimbursement is $46.90.
                                                            
}

