#include <iostream>				// include input/output library code
#include <iomanip>				//  output to have a two decimal places (xx.xx)
using namespace std;				// allows all of the names in a namespace
						// to be accessed without the namespace
						// identifier as a qualifier
int main ()
{
	float first;						// get first number
	float second;						// get second number
	cout << "****************************" << endl;	
	cout << "Calvin Cottrell" << endl;			// name
	cout << "ID @02653347" << endl;				// ID number
	cout << "SYCS-135 Computer Science I" << endl;		// course
	cout << "Lab 3" << endl;				// lab 3
	cout << "September 8, 2010" << endl;			// date
	cout << "***************************" << endl;
	cout << endl;						// new line
	cout << "MILAGE REIMBURSMENT CALCULATOR" << endl;	// title
	cout << endl;						// new line
	cout << "Enter beginning odometer reading=> " ;		//prompt use to enter milage 
	cin >> first;						// output number
	cout << endl;						// new line					
	cout << "Enter ending odometer reading=> " ;		// prompt user to enter ending milage
	cin >> second;						// output number
	cout << endl;
	float milage = (second - first);			// subtract first number from last number
	cout << fixed << showpoint;
	cout << setprecision(2) << "You traveled " << milage << " miles. At $.35 cents a mile, your reimburstment is $" << (milage * .35) << endl; // multiply .35 by difference
	cout << endl;
	system ("pause");
	return 0;
}
// ****************************
// Calvin Cottrell
// ID @02653347
// SYCS-135 Computer Science I
// Lab 3
// September 8, 2010
// ***************************
//
// MILAGE REIMBURSMENT CALCULATOR
//
// Enter beginning odometer reading=> 100
//
// Enter ending odometer reading=> 120
//
// You traveled 20.00 miles. At $.35 cents a mile, your reimburstment is $7.00
//
// Press any key to continue . . .
//