#include <iostream>		// include input/output library code
#include <string>		// include string manipulate library code     
using namespace std;	// to be accessed without the namespace

int main()
{
	cout << "************************************" << endl;	//heading
	cout << "Tene'e Ingram" << endl;
	cout << "@02644283" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "************************************" << endl;

	cout << "AREA CALCULATOR" << endl;	//title

	int side;	//identify variable                                       
	cout << "Enter the number of inches of a side =>"; //prompt user for the length of the side
	cin >> side;	//get the lenght of the side from user		          
	cout << "The area is " << side*side;	//output the area of the shape


	system ("pause");
	return 0;

//************************************
Tene'e Ingram
@02644283
Lab 3
September 8, 2010
************************************
AREA CALCULATOR
Enter the number of inches of a side =>12
The area is 144
Press any key to continue . .
