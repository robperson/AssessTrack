1>------ Build started: Project: helloworld, Configuration: Debug Win32 ------
1>Compiling...
1>helloworld.cpp
1>Build log was saved at "file://c:\Users\rdavis\Desktop\Visual Studio 2008\projects\helloworld\helloworld\Debug\BuildLog.htm"
1>helloworld - 0 error(s), 0 warning(s)
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========
