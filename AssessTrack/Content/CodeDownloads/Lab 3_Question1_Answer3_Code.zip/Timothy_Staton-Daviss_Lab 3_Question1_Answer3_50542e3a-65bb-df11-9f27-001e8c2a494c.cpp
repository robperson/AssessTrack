#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	cout << "*********************\n";
	cout << "Howard Student\n";
	cout << "ID @123456\n";
	cout << "SYCS-135 Computer Science 1\n";
	cout << "Lab 3\n";
	cout << "September 7, 2010\n";
	cout << "*********************\n\n";

	cout << "MILEAGE REIMBURSEMENT CALCULATOR\n\n";
	float begin;
	float end;
	float final;
	float rate = .35;
	float cost;

	cout << "Enter beginning odometer reading=> ";  //1. Promt user input.
	cin >> begin;		//2. Get user input.
	cout << "\nEnter ending odometer reading=> ";   //3. Prompt user input.
	cin >> end;		//4. Get user input.
	final = end - begin;	//5. Subtract ending input from beginning input.
	cost = final * rate;	//6. Multiply difference by .35

	cout << fixed << showpoint;
	cout << setprecision(2) << "\nYou traveled " << final << " miles.";  
	cout << setprecision(2) << "  At $.35 per mile, your reimbursement is $" << cost << "."; 
	return 0;

}
//*********************
//Howard Student
//ID @123456
//SYCS-135 Computer Science 1
//Lab 3
//September 7, 2010
//*********************

//MILEAGE REIMBURSEMENT CALCULATOR

//Enter beginning odometer reading=> 505

//Enter ending odometer reading=> 550

//You traveled 45.00 miles.  At $.35 per mile, your reimbursement is $15.75.