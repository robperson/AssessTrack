#include <iostream>                        
#include <string>                          
#include <iomanip>
using namespace std;                       
                                           
                                           

int main()
{
	cout << "***************************" << endl;
	cout << "Malachi Harris-Schirner" << endl;
	cout << "ID @02645004" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8,2010" << endl;
	cout << "***************************" << endl << endl;
	cout << "MILAGE REIMBURSMENT CALCULATOR" << endl << endl; 
	float beginning_number;
	cout << "Enter beginning odometer reading=> " << endl;
	cin >> beginning_number;
	float ending_number;
	cout << "Enter ending odometer reading=> " << endl;
	cin >> ending_number;
	cout << "you traveled " << ending_number-beginning_number << "miles. At $0.35 per mile, your reimbersment is $" << fixed << showpoint << setprecision(2) << (ending_number-beginning_number)*0.35 << endl;
}
// ***************************
// Malachi Harris-Schirner
// ID @02645004
// SYCS-135 Computer Science I
// Lab 3
// September 8,2010
// ***************************
// MILAGE REIMBURSMENT CALCULATOR
// Enter beginning odometer reading=> 55044
// Enter ending odometer reading=> 55178
// you traveled 134miles. At $0.35 per mile, your reimbersment is $46.90