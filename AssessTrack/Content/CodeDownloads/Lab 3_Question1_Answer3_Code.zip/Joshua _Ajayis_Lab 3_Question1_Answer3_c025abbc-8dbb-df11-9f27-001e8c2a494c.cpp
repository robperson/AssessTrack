#include <iostream>                        // include input/output library code
#include <string>
#include <iomanip>							// include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << fixed << showpoint;
	cout << "****************************" << endl;
	cout << "Joshua Ajayi" << endl;
	cout << "ID @02646816" << endl; 
	cout << "SYCS-135 Computer Science 1" << endl;
	cout << "Lab 3" << endl;
	cout << "September, 8, 2010" << endl;
	cout << "****************************" << endl;
	cout << " " << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
	cout << " " << endl;
	cout << " " << endl;
	int beginning_number; 
	cout << "Enter beginning odometer reading=>" << endl; 
	cin >> beginning_number; 
	int ending_number;
	cout << " " << endl;
	cout << "Enter ending odometer reading=>" << endl;
	cin >> ending_number;
	cout << " " << endl;
	cout << setprecision(2) << "You have traveled " << ending_number-beginning_number << " At $.35 per mile, your reimbursement is "; 
	int mileage = (ending_number-beginning_number);
	cout << mileage*0.35 << endl; 
	// ****************************
//Joshua Ajayi
//ID @02646816
//SYCS-135 Computer Science 1
//Lab 3
//September, 8, 2010
//****************************
//
//MILEAGE REIMBURSEMENT CALCULATOR
//
//Enter beginning odometer reading=>
//2
//
//Enter ending odometer reading=>
//3
//
//You have traveled 1 At $.35 per mile, your reimbursement is 0.35
//Press any key to continue . . .
}

        