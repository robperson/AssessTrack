#include <iostream>
using namespace std;

int main()
{
		cout << "I'm hungry!....gimme some food" << endl;
		return 0;
}