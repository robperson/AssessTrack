#include <iostream>
#include <string>
#include <iomanip>
using namespace std;

int main ()
{
	float milea;
	float mileb;
	float milestraveled;
	float mileage;
	cout << fixed << showpoint;
	cout <<"Enter beginning odometer reading=> " <<endl;
	cin >> milea;
	cout <<"Enter ending odometer reading=> " <<endl;
	cin >> mileb;
	milestraveled=(mileb-milea);
	mileage=(milestraveled*0.35);
	cout << setprecision(2)<<"You Traveled " << milestraveled<< " miles. At $.35 per mile, your reinbursement is $" <<mileage<< '.'<<endl;
	system("PAUSE");
	return 0;
}
/*Enter beginning odometer reading=>
55044
Enter ending odometer reading=>
55178
You Traveled 134.00 miles. At $.35 per mile, your reinbursement is $46.90.
Press any key to continue . . .*/
        