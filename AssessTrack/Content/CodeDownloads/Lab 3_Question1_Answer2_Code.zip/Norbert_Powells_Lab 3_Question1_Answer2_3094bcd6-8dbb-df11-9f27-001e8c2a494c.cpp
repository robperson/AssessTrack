#include <iostream>
#include <string>
using namespace std;

int main()
{
	cout << "****************************\nHoward Student\nID 02642070\nSYCS-135 Computer Science I\nLab 3\nSeptember 8, 2010\n****************************\n\n";
	int side=0;
	cout << "Area Calculator\n\nEnter the Number of inches a Sides=>";//1) prompt user input//
	cin >> side;//2) get user input//
	cout <<endl << "The area is " << side*side << endl;//)3 multiply input by itself////4) output data //	
	system("pause");
	return 0;
	/*****************************
Howard Student
ID 02642070
SYCS-135 Computer Science I
Lab 3
September 8, 2010
****************************

Area Calculator

Enter the Number of inches a Sides=>12

The area is 144
Press any key to continue . . .*/
}


        