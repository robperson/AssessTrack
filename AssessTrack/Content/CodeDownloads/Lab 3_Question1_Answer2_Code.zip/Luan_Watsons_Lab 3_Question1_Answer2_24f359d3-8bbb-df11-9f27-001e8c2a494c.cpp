


#include <iostream>                        
#include <string>                          
using namespace std;                       
int main()
{
    float numinches;   
	float area; 
	cout<<"******************* \n";
		cout<<"Howard Student \n";
		cout<<"ID @02606296 \n";
		cout<<"SYCS-135 Computer Science I\n";
		cout<<"Lab 3 \n";
		cout<<"September 8, 2010 \n \n";
		cout<<"AREA CALCULATOR \n \n";
		cout<<"Enter number of inches of a side=>"; //Promt user input 
		cin>> numinches; //Get user input
		area= numinches*numinches; //multiply input by itself
		cout<<"The area is " << area; //output data
return 0;
}

//*******************
//Howard Student
//ID @02606296
//SYCS-135 Computer Science I
//Lab 3
//September 8, 2010
//AREA CALCULATOR

//Enter number of inches of a side=>12
//The area is
//144Press any key to continue . . .
