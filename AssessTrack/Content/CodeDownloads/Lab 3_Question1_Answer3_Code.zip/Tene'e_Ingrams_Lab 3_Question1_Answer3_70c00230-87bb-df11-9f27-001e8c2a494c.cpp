#include <iostream>	// include input/output library code
#include <string>	// include string manipulate library code
#include <iomanip>      //include variables with two decimals places
using namespace std;	// to be accessed without the namespace

int main()
{
	cout << "************************************" << endl;  //heading
	cout << "Tene'e Ingram" << endl;
	cout << "@02644283" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "************************************" << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl; //title
	float b;	//identify variables
	float e;	//identify variables
	cout << "Enter beginning odometer reading =>";	//prompt the user for the beginning odometer reading
	cin >> b;	//get beginning odometer reading from user
	cout << "Enter ending odometer reading =>";		//prompt the user for the ending odometer reading
	cin >> e;	//get ending odometer reading from user
	cout << fixed << showpoint;	//
	cout << setprecision(2) << "You traveled " << e-b <<  "miles."; //output the number of miles traveled
	cout << setprecision(2)<< " At $.35 per mile, your reimbursment is $" << 0.35 * (e-b)<< endl; //out put the amount of gas spent in dollar amount
	return 0;
}

//************************************
Tene'e Ingram
@02644283
Lab 3
September 8, 2010
************************************
MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading =>55044
Enter ending odometer reading =>55178
You traveled 134.00miles. At $.35 per mile, your reimbursment is $46.90
Press any key to continue . . .
       