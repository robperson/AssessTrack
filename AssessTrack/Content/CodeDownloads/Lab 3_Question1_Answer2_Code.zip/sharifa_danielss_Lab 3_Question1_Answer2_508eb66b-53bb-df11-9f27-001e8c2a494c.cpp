#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
            
int main()
{
        int x;                     
        cout << "**********************" <<endl;        
        cout << "Howard Student" <<endl;
		cout << "ID @02598115" <<endl;
		cout << "SYCS-135 Computer Science I" <<endl;
		cout << "Assignment 3" <<endl;
		cout << "September 7, 2010" <<endl;
		cout << "**********************" <<endl;
		cout <<endl;
		cout << "AREA CALCULATOR" <<endl;
		cout <<endl;
		cout << "Enter the number of inches of a side => ";
		cin >> x;   
		cout << "The area is " << x*x << endl; 
	return 0;    
}
/***********************
Howard Student
ID @02598115
SYCS-135 Computer Science I
Assignment 3
September 7, 2010
**********************

AREA CALCULATOR

Enter the number of inches of a side => 12
The area is 144
Press any key to continue . . .*/