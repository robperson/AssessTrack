        #include <iostream>
using namespace std;

int main ()
{
	cout << "hello world. Joshua Ajayi" << endl;
	return 0;
}
