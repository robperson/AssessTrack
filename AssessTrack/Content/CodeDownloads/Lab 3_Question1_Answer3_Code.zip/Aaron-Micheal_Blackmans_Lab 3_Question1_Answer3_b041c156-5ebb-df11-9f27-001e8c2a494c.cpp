#include <iostream>
#include <string>
#include <iomanip>
using namespace std;
const float RATE=0.35; 
int main()
{
 cout << "*************************** " << endl; // Display line of stars
 cout << "Howard Student " << endl; // Display "Howard Student"
 cout << "ID @02626082 " << endl; // Display ID#
 cout << "SYCS-135 Computer Science I " << endl; // Display "SYCS-135 Computer Science I"
 cout << "Lab 3 " << endl; // Display "Lab 3"
 cout << "September 7, 2010 " << endl; // Display "September 7, 2010"
 cout << "*************************** " << endl; // Display line of stars
 cout << endl; // end line / skip line
 cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl; // Display "MILEAGE REIMBUSEMENT CALCULATOR"
 float start; // Declare float(decimal) variable to store starting mileage
 float end; // Declare float (decimal) variable to store ending mileage
 cout << fixed << showpoint;
 cout << "Enter beginning odometer reading => " ; // Prompt user for start mileage
 cin >> start; // get start mileage from user
 cout << "Enter ending odometer reading => " ; // Prompt user for end mileage
 cin >> end; // get end mileage from user
 cout <<setprecision(2) << "you traveled " << end-start << "miles. At $.35 per mile, your reimbursement is " << (end-start)*RATE << endl; // output message set at two decimal places
 return 0; // return program completed OK
//***************************
//Howard Student
//ID @02626082
//SYCS-135 Computer Science I
//Lab 3
//September 7, 2010
//***************************
//
//MILEAGE REIMBURSEMENT CALCULATOR
//Enter beginning odometer reading => 550
//Enter ending odometer reading => 600
//you traveled 50.00miles. At $.35 per mile, your reimbursement is 17.50
}