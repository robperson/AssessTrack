#include <iostream>                        // include input/output library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
        int sideofsquare;                     // 1.  declare variable to store the side of the square 
        cout << "Enter one side of the square";        // 2.  prompt the user for the side of the square
        cin >> sideofsquare;                     // 3.  get side of the square from user
	cout << "The area is" << sideofsquare * sideofsquare << endl; // 4.  output message
	return 0;                          // return program completed OK to
                                           // the operating system
}


//Enter one side of the square 10
//The area is 100