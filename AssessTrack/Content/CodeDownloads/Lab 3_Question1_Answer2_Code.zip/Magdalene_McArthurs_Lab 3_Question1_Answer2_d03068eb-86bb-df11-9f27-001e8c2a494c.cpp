#include <iostream>
#include <string>
using namespace std;
int main()
{
    cout<<"***************************"<< endl;
    cout<<"Magdalene McArthur"<< endl;
    cout<<"ID @02645775"<< endl;
    cout<<"SYCS-135 Computer Science I"<< endl;
    cout<<"Lab 3"<< endl;
    cout<<"September 8, 2010"<< endl;
    cout<<"***************************"<< endl;
    int side;                               
    cout<<"Enter one side of the square=>";     //1.prompt user input
    cin>> side;                                 //2.get user input
    cout<<"The area is"<<side*side<< endl;      //3.multiply input by itself
    return 0;                                   //4.output data
//***************************
//Magdalene McArthur
//ID @02645775
//SYCS-135 Computer Science I
//Lab 3
//September 8, 2010
//***************************
//Enter one side of the square=>5
//The area is25
//Press any key to continue . . .
}



