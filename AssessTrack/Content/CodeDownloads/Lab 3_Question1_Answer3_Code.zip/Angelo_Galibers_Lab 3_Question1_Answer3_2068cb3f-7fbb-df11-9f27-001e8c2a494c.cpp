#include <iostream>
#include <iomanip>
using namespace std;                                          
                                           
int main()
{
    cout << "*************************** " << endl;
    cout << "Angelo Galiber " << endl;
    cout << "ID @02647561 " << endl;
    cout << "SYCS-135 Computer Science I " << endl;
    cout << "Lab 3 " << endl;
    cout << "September 8, 2010 " << endl;
    cout << "***************************" << endl << endl;
	cout << "MILAGE REIMBURSEMENT CALCULATOR " << endl << endl;
	
	float beginning;
	float ending;
	float reimbursment;
	float mileage;
	cout << fixed << showpoint;  
	cout <<"Enter beginning odometer reading=> " << endl; //Prompt user input
	cin >> beginning;									   //Get user input
	cout << endl << "Enter ending odometer reading=> " << endl;  //Prompt user input
	cin >> ending;										//Get user input
	const float rate = .35;
	mileage = ending - beginning; //Subtract ending input from beginning input
	reimbursment = rate * mileage; //Multiply difference by .35
	cout << endl << setprecision(2) << "You traveled " << mileage << " miles. " << "At $.35 per mile, your reimbursment is $" << reimbursment << endl; //Output data
	return 0;
}
/****************************
Angelo Galiber
ID @02647561
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***************************

MILAGE REIMBURSEMENT CALCULATOR
Enter beginning odometer reading=>
55044
Enter ending odometer reading=>
55178
You traveled 134.00 miles. At $.35 per mile, your reimbursment is $46.90
Press any key to continue . . .*/