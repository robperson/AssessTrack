#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
    cout << "*****************************" << endl;
    cout << "Samuel Omosuyi" << endl;
    cout << "@02623937" << endl;
    cout << "Sycs-135 Computer Science 1" << endl;
    cout << "Lab 3" << endl;
    cout << "September 7, 2010" << endl;
    cout << "*****************************" << endl << endl;

    cout << "AREA CALCULATOR" << endl << endl;
    int squareside;                                        // 1.  declare 
variable to store the side of the square                    

    cout << "Enter one side of square ";                  // 2.  prompt the 
user for one side of square
    cin >> squareside;                                    // 3.  get square 
from user
    squareside = squareside * squareside;                  // 4.  calculates the 
area of the square
    cout << "The area is " << squareside << endl;          // 5.  output message
    return 0;                                              // return program 
completed OK to
                                                          // the operating 
system
}

//*****************************
//Samuel Omosuyi
//@02623937
//Sycs-135 Computer Science 1
//Lab 3
//September 7, 2010
//*****************************

//AREA CALCULATOR

//Enter one side of square 10
//The area is 100

        