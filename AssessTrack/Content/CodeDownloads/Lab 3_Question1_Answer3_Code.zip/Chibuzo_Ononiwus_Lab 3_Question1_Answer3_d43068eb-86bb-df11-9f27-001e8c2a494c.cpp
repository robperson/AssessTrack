#include <iostream>                        // include input/output library code
#include <string>  
#include <iomanip>					// include string manipulate library code
using namespace std; 
									// allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout<< "**********************************"<<endl;
	cout<<"Chibuzo Ononiwu"<<endl;
	cout<<"ID @02627330"<<endl;
	cout<<"SYCS-135 Computer Science I"<<endl;
	cout<<"Lab 3"<<endl;
	cout<<"September 8,2010"<<endl;
	cout<<"***********************************"<<endl<<endl;
	cout<<"MILAGE REIMBURSEMENT CALCULATOR"<<endl<<endl;
	float beginning; 
	float ending;
	float difference;										// 1.  declare variable to input
    cout << "Enter beginning odometer reading=> ";        // 2.  prompt the user for input
    cin >> beginning;  
	cout << "\nEnter ending odometer reading=> ";        // 2.  prompt the user for input
    cin >> ending;
	difference= ending-beginning;
	cout<<	"\nYou have traveled " << difference;		// 3.  subtract ending input from beginning input
	cout << fixed << showpoint;
	cout << setprecision(2) << ".00 miles. At $.35 per mile, your reimbursement is $ "<< difference*.35 << endl; // 4.  multiply difference by .35
																				// return program completed OK to
																				   // the operating system
	
	
	return 0;                          
}

/*
**********************************
Chibuzo Ononiwu
ID @02627330
SYCS-135 Computer Science I
Lab 3
September 8,2010
***********************************

MILAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044

Enter ending odometer reading=> 55178

You have traveled 134.00 miles. At $.35 per mile, your reimbursement is $ 46.90
Press any key to continue . . .
*/