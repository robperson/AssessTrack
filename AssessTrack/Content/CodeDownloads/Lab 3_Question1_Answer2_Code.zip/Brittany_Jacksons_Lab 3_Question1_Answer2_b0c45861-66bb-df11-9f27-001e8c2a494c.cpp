#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier
int main()
{
  cout << "***********************" << endl;
                cout << "Brittany Jackson" << endl;            
  cout << "ID @02605575" << endl;
  cout << "SYCS-135 Computer Science" << endl;
  cout << "Lab 3" << endl;
  cout << "September 7, 2010" << endl;
  cout << "************************" << endl;
                cout << " " << endl;
  cout << "Area Calculator" << endl;
  cout << " " << endl;
  int area;                  // 1. Declare variable to store area
  int inches;      // 2. Declare variable to store area 
        cout << "Enter the number of inches of a side=>" << endl;  // 3. prompt the user for the inches of a side
  cin >> inches;                    // 4. get inches of side from user 
  area = inches * inches;            // 5. multiply input by itself
  cout << "The area is " << area << endl;                     // 6. Ouput message
   return 0;                                                      // return program completed OK to
                                                                   // the operating system
}
//***********************
//Brittany Jackson
//ID @02605575
//SYCS-135 Computer Science
//Lab 3
//September 7, 2010
//************************
//Area Calculator
//Enter the number of inches of a side=>
//12
//The area is 144
//Press any key to continue . . .

        