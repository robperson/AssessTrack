#include <iostream>
using namespace std;

int main ()
{
	cout<<"Hello Ty!"<< endl;
	return 0;
}
