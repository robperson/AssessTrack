#include <iostream>
#include <string>
using namespace std;

int main()
{
	cout << "********************************"<< endl;
	cout << "Antonio Ringgold" << endl;
	cout << "ID @02650261" << endl;
	cout << "SYCS-135 COmputer Science I"<< endl;
	cout << "Lab 3"<< endl;
	cout << "September 7, 2010"<< endl;
	cout << "********************************"<< endl << endl;
	cout << "AREA CALCULATOR "<< endl << endl;
	int sides;
	int area;
	cout << " Enter the number of inches of a side=> ";
	cin >> sides;
	area=sides*sides;
	cout << "the area is " << area  << endl;
	return 0;
}
/********************************
Antonio Ringgold
ID @02650261
SYCS-135 COmputer Science I
Lab 3
September 7, 2010
********************************

AREA CALCULATOR

Enter the number of inches of a side=>12

The area is 144
Press any key to continue . . .