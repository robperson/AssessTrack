#include <iostream> 
#include <string> 
#include <iomanip>
using namespace std; 
int main()
{
cout<< "************** "<< endl;
cout<< "Zachary Spence "<< endl;
cout<< "ID @02653782 "<< endl;
cout<< "SYCS - 135 Computer Science I "<< endl;
cout<< "Assign 3 "<< endl;
cout<< "September 8, 2010 "<< endl;
cout<< "************** "<< endl;
int begin;
int end;
int cat;
cout << "Mileage Reimbursement Calc "<<endl;
cout<< "Enter beginning Odometer reading=> "<<endl;
cin >> begin;
cout<< "Enter ending Odometer reading=> "<<endl;
cin >> end; 
cat = end - begin;
cout << fixed << showpoint;
cout << setprecision(2) << "You Traveled " << cat << "miles. At $.35 per mile, your reimbursement is $" << cat * .35 << endl; 
return 0;
}

/*
**************
Zachary Spence
ID @02653782
SYCS - 135 Computer Science I
Assign 3
September 8, 2010
**************
Mileage Reimbursement Calc
Enter beginning Odometer reading=>
55044
Enter ending Odometer reading=>
55178
You Traveled 134miles. At $.35 per mile, your reimbursement is $46.90
Press any key to continue . . .
*/
        