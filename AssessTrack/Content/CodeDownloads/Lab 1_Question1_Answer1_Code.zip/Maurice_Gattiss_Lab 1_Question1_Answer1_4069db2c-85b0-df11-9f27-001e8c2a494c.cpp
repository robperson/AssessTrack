#include <iostream>
using namespace std;

int main()
{
	cout << "I Am A Howard Man" << endl;
	return 0;
}

//I Am A Howard Man