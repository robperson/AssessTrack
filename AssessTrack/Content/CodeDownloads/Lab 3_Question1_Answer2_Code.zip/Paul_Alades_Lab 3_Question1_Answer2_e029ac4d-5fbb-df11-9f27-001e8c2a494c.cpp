#include <iostream>                        // include input/output library code
#include <iomanip>                         
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           
int main()
{
  cout << "****************************" << endl;
  cout << "Paul Alade" << endl;
  cout << "@02620333" << endl;
  cout << "SYCS-135 Computer Science I" << endl;
  cout << "Lab 3" << endl;
  cout << "September 7, 2010" << endl;
  cout << "****************************" << endl << endl;
  cout << "AREA CALCULAOR" << endl << endl;
        int length;            // 1.  declare variable to store length 
        cout << "Enter the number of inches of a side = ";      // 2.  prompt the user for length
        cin >> length;           // 3.  get length from user
  length = length * length;        // 4.  calculate area = length * length
  cout << "The Area is " <<length << endl;    // 5.  output message
 return 0;                          
                                       
}
/*
****************************
Paul Alade
@02620333
SYCS-135 Computer Science I
Lab 3
September 7, 2010
****************************
AREA CALCULAOR
Enter the number of inches of a side = 16
The Area is 256
Press any key to continue . . . */