#include <iomanip>                        
#include <string>  
#include <iostream>
using namespace std;                       
                                       
                                           
int main()
{
  
     float miles1;      
  float miles2;
  const float Rate=0.35; 
  cout << fixed << showpoint;
  cout << "Enter beginning odometer reading=> " << endl;
  cin  >> miles1;
  cout << "Enter ending odometer reading=> "<<endl;
  cin  >> miles2;                                  
  cout << setprecision(2)<<"You traveled " << miles2-miles1 << '.'<< " At $.35 per mile, your reimbursement is " << (miles2-miles1)* Rate << endl;
  
  return 0;                                     
                                                      
}
 
Enter beginning odometer reading=>
10
Enter ending odometer reading=>
15
You traveled 5.00. At $.35 per mile, your reimbursement is 1.75