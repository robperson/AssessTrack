#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << "***************************" << endl;
	cout << "Najee K. Jeremiah" << endl;
	cout << "ID @02625680" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "Assignment 3" << endl;
	cout << "september 8, 2010" << endl;
	cout << "***************************" << endl;
	cout << " " << endl;
	cout << "AREA CALCULATOR" << endl;
	cout << " " << endl;
        int length, area;                  // 1.  declare variables to store my values 
        cout << "Enter the number of inches of a size:> "; // 2.  prompt to enter a number
        cin >> length;                     // 3.  get value from user
		area = length * length;            // 4. Multiply Length by Length
		cout << " " << endl;
	    cout << "The Area is " << area << endl; // 5.  output message
	    return 0;                         // return program completed OK to
                                           // the operating system
}
