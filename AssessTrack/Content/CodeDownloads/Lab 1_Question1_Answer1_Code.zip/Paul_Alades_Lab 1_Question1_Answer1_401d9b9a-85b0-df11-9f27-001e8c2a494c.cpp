#include <iostream>
using namespace std;

int main()
{
	cout << "Paul Alade" << endl;
	return 0;
}

/* Output: Paul Alade */       