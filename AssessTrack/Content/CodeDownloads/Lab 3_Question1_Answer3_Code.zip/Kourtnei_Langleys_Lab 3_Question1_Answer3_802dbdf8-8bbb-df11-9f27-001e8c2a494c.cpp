#include <iostream>    
#include <string> 
#include <iomanip>
using namespace std; 

float main ()

{

	float mynumber1; float mynumber2; 
	cout << "**************************" <<endl;
	cout << "Kourtnei Langley" <<endl; 
	cout << "ID @02641815" <<endl;
	cout << "SYCS 135 Computer Science I" <<endl;
	cout << "Lab 3"  <<endl;
	cout << "Septemeber 8, 2010" <<endl;
	cout << "**************************" <<endl;
	cout << " " <<endl; 
	cout << "Mileage Reimbursement Calculator" <<endl; 
	cout << " " <<endl; 
	cout << "Enter the beginning odometer reading "; 
	cin>> mynumber1;
	cout << " " <<endl;
	cout << "Enter ending odometer reading ";
	cin>> mynumber2;
	cout << " " <<endl;
	cout << fixed << showpoint;
	cout << setprecision(2) << "You traveled "<<mynumber2-mynumber1 << " miles."; 
	cout << " At $.35 per mile your reimbursement is $" <<(mynumber2-mynumber1) *.35<<endl; 
	cout << " " <<endl; 
	system ("pause");
	return 0;	 

}

//**************************
//Kourtnei Langley
//ID @02641815
//SYCS 135 Computer Science I
//Lab 3
//Septemeber 8, 2010
//**************************

//Mileage Reimbursement Calculator

//Enter the beginning odometer reading 55044

//Enter ending odometer reading 55178

//You traveled 134.00 miles. At $.35 per mile your reimbursement is $46.90

//Press any key to continue . . .

        