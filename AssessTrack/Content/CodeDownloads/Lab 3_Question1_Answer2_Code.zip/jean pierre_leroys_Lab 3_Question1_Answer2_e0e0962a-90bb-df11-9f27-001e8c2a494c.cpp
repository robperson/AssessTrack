#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
	cout << "****************************" << endl;
	cout << "Jean Pierre Leroy" << endl;
	cout << "ID @02647910" << endl;
	cout << "SYCS-135 Computer Science I" << endl;
	cout << "lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "****************************" << endl;
	cout << "AREA CALCULATOR" << endl;
	int number;
	cout << "Enter one side of the square=>" << endl;
	cin >> number;
	cout << " The area is" << number*number << endl;
	return 0;
}
        