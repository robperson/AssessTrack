//MILEAGE REIMBURSEMENT CALCULATOR program
//main function serves to calculate the appropriate mileage reimbursement
#include <iostream>                        // Include input/output library code
#include <string>                          // Include string manipulate library code
#include <iomanip>                         //Include input/output manipulator code
using namespace std;                       // Allows all of the names in a namespace
                                           // to be accessed without the namespace
                                           // identifier as a qualifier
const float nReimbursementRate = .35;      //Declare and assign value of $0.35 for reimbursement rate
void PrintHeading(void);                   //Function prototype for PrintHeading function
int main()
{
    float nOdometerBegin;                 //Declare variable to store beginning odometer reading
    float nOdometerEnd;                   //Declare variable to store ending odometer reading
	float nMilesTraveled;                 //Declare variable to store miles traveled
	float nReimbursementAmount;           //Declare variable to store reimbursement amount
    PrintHeading();                       //Print student heading
    cout<<"MILEAGE REIMBURSEMENT CALCULATOR\n\n"; //Title of program
    cout<<"Enter beginning odometer reading=> ";  //Prompt user to enter beginning odometer reading
	cin>>nOdometerBegin;                          //Retreive and store user input into the variable for the beginning odometer reading
	cout<<endl;                                   //Skip a line
	cout<<"Enter ending odometer reading=> ";     //Prompt user to enter ending odometer reading
    cin>>nOdometerEnd;                            //Retreive and store user input into the variable for the ending odometer reading
	cout<<endl;                                   //Skip a line
    nMilesTraveled = nOdometerEnd - nOdometerBegin;              //Compute miles traveled and store into variable for miles traveled
	nReimbursementAmount = nMilesTraveled * nReimbursementRate;  //Compute reimbursement amount and store into variable for the reimbursement amount
    cout<<"You traveled " << fixed << showpoint << setprecision(2) 
	<< nMilesTraveled << " miles." << " At $"<< nReimbursementRate << " per mile, your reimbursement is $" << nReimbursementAmount << endl; //Send desired output to screen
    return 0;                                          //Tell CPU that the program has successfully finished
}
void PrintHeading(void)
{
    string strAsterisks ="***************************";   //Declare and assign variable to row of asterisks
    string strHoward = "Howard Student";                  //Declare and assign variable to Howard Student
    string strIDNumber = "ID @02621362";                  //Declare and assign variable to id number
    string strClassTitle = "SYCS-135 Computer Science I"; //Declare and assign variable to course title
    string strTask = "Lab 3";                              //Declare and assign variable to task name
    string strDate = "September 8, 2010";                 //Declare and assign variable to date
    cout << strAsterisks << endl << strHoward << endl << strIDNumber << endl << strClassTitle << endl << strTask 
	<< endl << strDate << endl << strAsterisks << endl << endl; //Send heading to output
}/*
***************************
Howard Student
ID @02621362
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 8000

Enter ending odometer reading=> 9000

You traveled 1000.00 miles. At $0.35 per mile, your reimbursement is $350.00
*/