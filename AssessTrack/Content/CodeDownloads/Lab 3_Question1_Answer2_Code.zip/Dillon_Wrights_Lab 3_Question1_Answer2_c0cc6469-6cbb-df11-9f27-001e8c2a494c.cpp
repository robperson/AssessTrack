#include <iostream>                     // include input/output library code
using namespace std;                    // allows all of the names in a namespace 
                                         // to be accessed without the namespace 
                                         // identifier as a qualifier

int main()
{
	int INCHES;                            // 1.  declare variable to store my
	int AREA;
	cout << "Enter number of inches of a side" << endl;            // 2.  prompt the user for number
	cin >> INCHES;                                                 // 3.  get number from user

	AREA = INCHES * INCHES;
	cout << "****************" << endl;                            // Writes my information on the screen.  
	cout << "Howard Student" << endl;
	cout << "SYCS-135 Computer I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "*****************" << endl;
	cout <<endl;
	cout << "Area Calculator." << endl;
	     
	cout << "The area is " << " => " << AREA << endl;            // 4.  output message

return 0;                                                        // return program completed OK to
                                                                // the operating system
}
//Enter number of inches of a side
//4
//****************
//Howard Student
//SYCS-135 Computer I
//Lab 3
//September 8, 2010
//*****************

//Area Calculator.
//The area is  => 16
//Press any key to continue . . .


        