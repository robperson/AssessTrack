       #include <iostream>                        
#include <string>                          
using namespace std;                      
#include <iomanip>                                        
                                           

int main()
{
        float od1, od2, distance;                   
        cout << "**************************" << endl;
		cout << "Qamar Muhaimin" << endl;
		cout << "ID @02657007" << endl;
		cout << "SYCS-135 Computer Science I" << endl;
		cout << "Lab 3" << endl;
		cout << "September 8,2010" << endl;
		cout << "**************************" << endl;
        cout << "" << endl;
		cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl;
		cout << "" << endl;
		cout << "Enter beginning odometer reading=> ";
        cin >> od1;
		cout << "" << endl;
		cout << "Enter ending odometer reading=> ";
		cin >> od2;
        cout << "" << endl;
        cout << fixed << showpoint;
	    distance= od2-od1;
		cout << "You traveled " << setprecision(2)<< distance << " miles. At $.35 per mile, your reimbursement is $46.90." << endl;
	 
	return 0;                         
                                           
}

//**************************
//Qamar Muhaimin
//ID @02657007
//SYCS-135 Computer Science I
//Lab 3
//September 8,2010
//**************************

//MILEAGE REIMBURSEMENT CALCULATOR

//Enter beginning odometer reading=> 55044

//Enter ending odometer reading=> 55178

//You traveled 134.00 miles. At $.35 per mile, your reimbursement is $46.90.
//Press any key to continue . . .
