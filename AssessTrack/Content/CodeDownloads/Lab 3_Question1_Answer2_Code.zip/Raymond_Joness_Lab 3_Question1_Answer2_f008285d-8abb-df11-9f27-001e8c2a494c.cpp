#include<iostream> //for cout, endl
#include<string>
using namespace std;
int Square( int );//Square function

	int main()
{
	const string line = "***************************";//Border
	cout << line << endl;
	cout << "Howard University" << endl;
	cout << "ID @123456" << endl;
	cout << "SYCS-135 Computer Science I" <<endl;
	cout << "Lab 3" << endl;
	cout << "September 7, 2010" << endl;
	cout << line << endl << endl;
	cout << "AREA CALCULATOR" << endl << endl;
	cout << "Enter the number of inches of a side=> ";
	int number;//Number of inches of a side
	cin >> number;
	cout << endl;
	cout << "The area is " << Square (number) << endl;
	system("pause");
	return 0;
}
	int Square( int n )
	{
		return n * n;
	}