#include <iostream>
using namespace std;
void main()
{
   cout<<"This code compiled and this is the output."<<endl;
}
        