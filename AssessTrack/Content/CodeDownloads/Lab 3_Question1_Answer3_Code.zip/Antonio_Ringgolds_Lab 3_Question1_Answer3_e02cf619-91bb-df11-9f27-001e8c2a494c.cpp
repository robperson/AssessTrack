#include <iostream>
#include <iomanip>
using namespace std;

int main()
{
	cout << "********************************"<< endl;
	cout << "Antonio Ringgold" << endl;
	cout << "ID @02650261" << endl;
	cout << "SYCS-135 COmputer Science I"<< endl;
	cout << "Assignment 3"<< endl;
	cout << "September 7, 2010"<< endl;
	cout << "********************************"<< endl << endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
	float beginning;
	float ending;
	float totalmiles;
	cout << "Enter beginning odometer reading=>" << endl;
	cin >> beginning;
	cout << endl << "Enter ending odometer reading=>";
	cin >> ending;
	cout << fixed << showpoint;
	totalmiles=ending-beginning;
	cout << endl << "You traveled" <<setprecision(2)<<totalmiles
		<< "miles, At $.35 per mile, your reimbursement is $"
		<<(ending-beginning) * 0.35 << endl << endl;
	return 0;
}
/********************************
Antonio Ringgold
ID @02650261
SYCS-135 COmputer Science I
Assignment 3
September 7, 2010
********************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=>55044

Enter ending odometer reading=>55178

You traveled 134.00 miles. At $.35 per mile, your reimbursement is $46.90

Press any key to continue . . .