#include <iostream>                   // include input/output library code
#include <string>                     // include string manipulate library code
#include <iomanip>
using namespace std;                  // allows all of the names in a namespace
                                      // to be accessed without the namespace 
                                      // identifier as a qualifier
const float rate = 0.35;              // delcares a float constant for the rate 
                                      // reimbursement
int main()
{
    //delclares variables
    float start, end, miles, reimburse;
    cout << "****************************\n";
    cout << "Jonathan Young\n";
    cout << "@02576822\n";
    cout << "SYCS-135 Computer Science 1\n";
    cout << "Lab 3\n";
    cout << "September 7, 2010\n";
    cout << "****************************\n\n";
    cout << "MILEAGE REIMBURSEMENT CALCULATOR\n\n";
    //prompts and retrieves data from user
    cout << "Enter beginning odometer reading=> ";
    cin >> start;
    cout << "\nEnter ending odometer reading=> ";
    cin >> end;
    cout << fixed << showpoint;
    //calculates the total number of miles traveled and the reimbursement
    miles = end - start;
    reimburse = rate * miles;
    //outputs message
    cout << setprecision(2) << "\nYou traveled " << miles << " miles. At " 
        << rate << " per mile your reimbursement is $" << reimburse << ".\n\n";
    return 0;  
}
 

/****************************
Jonathan Young
@02576822
SYCS-135 Computer Science 1
Lab 3
September 7, 2010
****************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 47600

Enter ending odometer reading=> 48329

You traveled 729.00 miles. At 0.35 per mile your reimbursement is $255.15.

Press any key to continue. . .*/