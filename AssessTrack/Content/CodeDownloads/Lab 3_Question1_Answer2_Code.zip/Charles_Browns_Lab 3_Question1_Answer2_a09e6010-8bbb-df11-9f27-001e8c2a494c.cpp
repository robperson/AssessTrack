#include <iostream>
using namespace std;

int main()
{
	int x;														// 1. declare variable to calculate value
	cout <<  "Enter the number of inches of a side" <<  endl;	// 2. prompt user to enter value
	cin >> x;													// 3. get value from user
	x = x * x;													// 4. multiply value by itself
	cout << "The area is " << x << endl;						// 5. output value
	return 0;
}