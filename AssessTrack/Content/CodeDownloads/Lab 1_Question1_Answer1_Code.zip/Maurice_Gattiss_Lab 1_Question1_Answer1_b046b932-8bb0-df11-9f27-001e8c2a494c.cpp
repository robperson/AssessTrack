#include <iostream>
using namespace std;

int main ()
{
		cout<< "I am a Howard man. Therefore, I am THE man." << endl;
		return 0;
}