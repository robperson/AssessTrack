#include <iostream>                        
#include <string>                          
using namespace std;                      
                                           
                                           

int main()
{
		cout<< "******************************** "<< endl;
		cout<< "Patrick Buah "<< endl;
		cout<< "ID @02648494 "<< endl;
		cout<< "SYCS - 135 Computer Science I "<< endl;
		cout<< "Lab 3 "<< endl;
		cout<< "September 8 2010 "<< endl;
		cout<< "******************************** "<< endl;
        int toSquare;                     
        cout << "AREA CALCULATOR "<<endl;
		cout<< "Enter the lenght of a side: "<<endl;
        cin >> toSquare;                     
		cout << "The Area is " + toSquare * toSquare << endl; 
	return 0;
}
/********************************
Patrick Buah
ID @02648494
SYCS - 135 Computer Science I
Lab 3
September 8 2010
********************************
AREA CALCULATOR
Enter the lenght of a side:
12
ID @02648494
Press any key to continue . . .
*/
        