#include <iostream>    
#include <string>   
using namespace std; 

int main ()

{

	int mynumber;
	cout << "**************************" <<endl;
	cout << "Kourtnei Langley" <<endl; 
	cout << "ID @02641815" <<endl;
	cout << "SYCS 135 Computer Science I" <<endl;
	cout << "Lab 3"  <<endl;
	cout << "Septemeber 8, 2010" <<endl;
	cout << "**************************" <<endl;
	cout << " " <<endl; 
	cout << "AREA CALCULATOR" <<endl; 
	cout << " " <<endl; 
	cout << "Enter the number of inches of a side "; 
	cin>> mynumber;
	cout << " " <<endl;
	cout << "The area is " << mynumber*mynumber <<endl; 
	system ("pause");
	return 0;	 

}

//**************************
//Kourtnei Langley
//ID @02641815
//SYCS 135 Computer Science I
//Lab 3
//Septemeber 8, 2010
//**************************

//AREA CALCULATOR

//Enter the number of inches of a side 12

//The area is 144
//Press any key to continue . . .

        