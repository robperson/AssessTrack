#include <iostream>                        // include input/output library code
#include <iomanip>                         
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           
int main()
{
  cout << "****************************" << endl;
  cout << "Paul Alade" << endl;
  cout << "@02620333" << endl;
  cout << "SYCS-135 Computer Science I" << endl;
  cout << "Lab 3" << endl;
  cout << "September 7, 2010" << endl;
  cout << "****************************" << endl << endl;
  cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
  cout << fixed << showpoint;
        float Initial;              // 1.  declare variable to store Initial odometer reading 
        cout << "Enter beginning odometer reading = ";      // 2.  prompt the user for Initial Odometer reading
        cin >> Initial;              // 3.  get initial odometer reading from user
        cout<< endl;
  
  float Final;              // 4.  declare variable to store final odometer reading 
  cout << "Enter ending odometer reading = ";       // 5.  prompt the user for Final Odometer reading
  cin >> Final;              // 6.  get Final odometer reading from user    
  cout << endl;  
  
  float Difference;             // 7.  declare variable to store Difference
  Difference = Final - Initial;          // 8.  calculate Difference = Final - Initial
  float Reimbursement;            // 9.  declare variable to store Reimbursement
  Reimbursement = Difference * .35;         // 10. calculate Reimbursement = Difference * .35
  cout << setprecision(2) << "You traveled " << Difference << " miles. At $.35 per mile, your reimbursement is $" << Reimbursement << endl;     // 11.  output message
  
 return 0;                          
                                       
}
/*
****************************
Paul Alade
@02620333
SYCS-135 Computer Science I
Lab 3
September 7, 2010
****************************
MILEAGE REIMBURSEMENT CALCULATOR
Enter beginning odometer reading = 145.76
Enter ending odometer reading = 190.52
You traveled 44.76 miles. At $.35 per mile, your reimbursement is $15.67
Press any key to continue . . .
*/