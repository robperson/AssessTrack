#include <iostream>                        // Include input/output library code
#include <string>                          // Include string manipulate library code
using namespace std;                       // Allows all of the names in a namespace
                                           // to be accessed without the namespace
                                           // identifier as a qualifier
void PrintHeading(void);                   //Function prototype for PrintHeading function
int main()
{
    int nLengthofSquare;                 //Declare variable to store length of sqaure
    int nAreaofSquare;                   //Declare variable to store area of square
    PrintHeading();                      //Print student heading
    cout<<"AREA CALCULATOR\n\n";         //Title of program
    cout<<"Enter length of square without units=> "; //Prompt user to enter length of square
    cin>>nLengthofSquare;                           //Retreive and store user input into the variable for the length of the sqaure
	cout<<endl;                                     //Skip a line
    nAreaofSquare = nLengthofSquare * nLengthofSquare; //Compute area and store into variable for the area of the square
    cout<<"The area is " << nAreaofSquare  << endl;    //Display calculated area
    return 0;                                          //Tell CPU program has successfully finished
}
void PrintHeading(void)
{
    const string strAsterisks ="***************************";   //Declare and assign variable to row of asterisks
    const string strHoward = "Howard Student";                  //Declare and assign variable to Howard Student
    const string strIDNumber = "ID @02621362";                  //Declare and assign variable to id number
    const string strClassTitle = "SYCS-135 Computer Science I"; //Declare and assign variable to course title
    string strTask = "Lab 3";                              //Declare and assign variable to task name
    string strDate = "September 8, 2010";                 //Declare and assign variable to date
    cout << strAsterisks << endl << strHoward << endl << strIDNumber << endl << strClassTitle << endl << strTask 
	<< endl << strDate << endl << strAsterisks << endl << endl; //Send heading to output
}/*
  ***************************
  Howard Student
  @02621362
  SYCS-135 Computer Science I
  Lab 3
  September 8, 2010
  ***************************

  AREA CALCULATOR

  Enter length of square without units=> 7

  The area is 49
  */