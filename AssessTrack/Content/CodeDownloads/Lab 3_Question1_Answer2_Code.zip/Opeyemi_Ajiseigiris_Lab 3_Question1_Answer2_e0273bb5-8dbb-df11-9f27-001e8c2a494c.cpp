#include <iostream>   //Include standard input and output files.
#include  <string>    //Includes the string llibrary code.
using namespace std;  //Use namespaces in standard llibrary.
int main()            //main Function.
{
	int side;         //Declaring side to be entered by user as a numberic integer.
	cout << "********************************************* \n";
	cout << "Howard Student \n";
	cout << "ID - @02647499 \n";
	cout << "SYCS-135 Computer Science I \n";
	cout << "Lab 3 \n";
	cout << "September 08, 2010 \n";
	cout << "********************************************* \n";

	cout << "AREA CALCULATOR \n";     //Stating the meaning and function of the code. 
	cout << "Enter the number of inches of a side => ";      //Prompting the user to enter a side.
	cin >> side;             //User enters a side
	cout << "The area is " <<side * side << "  \n";     //Area is calculated and answer is sjown on the scree.
	return 0;
}#include <iostream>   //Include standard input and output files.
#include  <string>    //Includes the string llibrary code.
using namespace std;  //Use namespaces in standard llibrary.
int main()            //main Function.
{
	int side;         //Declaring side to be entered by user as a numberic integer.
	cout << "********************************************* \n";
	cout << "Howard Student \n";
	cout << "ID - @02647499 \n";
	cout << "SYCS-135 Computer Science I \n";
	cout << "Lab 3 \n";
	cout << "September 08, 2010 \n";
	cout << "********************************************* \n";

	cout << "AREA CALCULATOR \n";     //Stating the meaning and function of the code. 
	cout << "Enter the number of inches of a side => ";      //Prompting the user to enter a side.
	cin >> side;             //User enters a side
	cout << "The area is " <<side * side << "  \n";     //Area is calculated and answer is sjown on the scree.
	return 0;
//*********************************************
//Howard Student
//ID - @02647499
//SYCS-135 Computer Science I
//Lab 3
//September 08, 2010
//*********************************************
//AREA CALCULATOR
//Enter the number of inches of a side => 12
//The area is 144
//Press any key to continue . . .
}