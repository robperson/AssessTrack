
  #include <iostream>                        
#include <string>  
#include <iomanip>
using namespace std;                                                                                                          
int main()
{
		int side;
		cout << fixed << showpoint;
		cout << "**************************" << endl;
		cout << "Ronnie Shaw" << endl;
		cout << "ID @02648299" << endl;
		cout << "SYCS-135 Computer Science I" << endl;
		cout << "lab 3" << endl;
		cout << "September 8, 2010" << endl;
		cout << "**************************" << endl << endl;
		cout << "MILEAGE REIMBURSEMENT CALCULATOR" << endl << endl;
		cout << "Enter beginning odometer reading=> ";
		cin >> side;
		cout << endl;
		cout << "Enter ending odometer reading=> ";
		cin >> side;
		cout << endl;
		cout << "You traveled miles. At $.35 per mile, your reimbursement is " << side*side <<endl;
		return 0;
}/***************************
Ronnie Shaw
ID @02648299
SYCS-135 Computer Science I
lab 3
September 8, 2010
**************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044

Enter ending odometer reading=> 55178

You traveled miles. At $.35 per mile, your reimbursement is -1250355612*/      