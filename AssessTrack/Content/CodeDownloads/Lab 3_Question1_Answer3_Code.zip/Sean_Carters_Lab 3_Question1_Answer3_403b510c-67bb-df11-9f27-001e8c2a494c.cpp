#include <iostream>                        // include input/output library code
#include <iomanip>
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier

int main()
{
        int mileage;                     // 1.  declare variable to store the mileage 
        cout << "Enter beginning odometer reading";        // 2.  prompt the user for the mileage
        cin >> mileage;                     // 3.  get mileage from the user
		int mileage2;
		cout << "Enter ending odometer reading";
		cin >> mileage2;
		cout << fixed << showpoint;
	cout << setprecision(2) << cout << "You traveled" << mileage2 - mileage << "At $.35 per mile, your reimbursement is" <<  (mileage2 - mileage) / .35 << endl; // 4.  output message
	return 0;                          // return program completed OK to
                                           // the operating system
}

//Enter beginning odometer reading 25
//Enter ending odometer reading 50
you traveled 25 miles at $.35 per mile your reimbursement is $8.75