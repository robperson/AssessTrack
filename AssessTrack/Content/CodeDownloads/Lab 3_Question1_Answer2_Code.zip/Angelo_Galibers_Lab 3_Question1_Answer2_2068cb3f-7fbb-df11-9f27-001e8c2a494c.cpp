#include <iostream>                                               
using namespace std;                                          
                                           
int main()
{
    cout << "*************************** " << endl;
    cout << "Angelo Galiber " << endl;
    cout << "ID @02647561 " << endl;
    cout << "SYCS-135 Computer Science I " << endl;
    cout << "Lab 3 " << endl;
    cout << "September 8, 2010 " << endl;
    cout << "***************************" << endl << endl;
    cout << "AREA CALCULATOR" << endl << endl;
    

    int inches;    
    cout << "Enter the number of inches of a side=>" << endl; //Prompt user input                                 
    cin >> inches; //Get user input                     
    cout << "The area is " << inches * inches /* Multiply input by itself */ << endl;     //Output data
    return 0;                                                                     
}
//***************************
//Angelo Galiber
//ID @02647561
//SYCS-135 Computer Science I
//Lab 3
//September 8, 2010
//***************************

//AREA CALCULATOR

//Enter the number of inches of a side=>
//12
//The area is 144
//Press any key to continue . . .        

        