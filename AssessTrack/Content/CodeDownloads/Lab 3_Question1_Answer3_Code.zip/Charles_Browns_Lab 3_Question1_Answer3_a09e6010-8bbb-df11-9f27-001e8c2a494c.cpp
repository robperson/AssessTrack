#include <iomanip>
#include <iostream>
using namespace std;

int main()
{
	float x,y;													// 1. identify variables
	cout <<  "Enter beginning odometer reading" <<  endl;		// 2. prompt user input
	cin >> x;													// 3. get user input
	cout <<  "Enter ending odometer reading" <<  endl;			// 4. prompt user input
	cin >> y;													// 5. get user input
	cout << fixed << showpoint;
	cout << "You traveled "<< setprecision(2)<<y-x<< "miles"<< endl;  // 6. multiply difference by .35
	cout << "At $.35 per mile, your reimbursement is $" << setprecision(2)<<(y-x)*.35 << endl;			// 7. output data		
	return 0;
}