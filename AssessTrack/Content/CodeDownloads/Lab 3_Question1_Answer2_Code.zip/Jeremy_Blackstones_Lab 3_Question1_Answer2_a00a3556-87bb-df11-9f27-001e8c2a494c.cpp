#include <iostream> // include input/output library code 
using namespace std;// allows all of the names in a namespace to be accessed without the  namespace 
					// identifier as a qualifier 
int main () // Find area of square
{
	int side;	// Declareside side variable
	int area;   // Declare area
	cout << "***************************"<< endl; // Enter stars
	cout << "Jeremy Blackstone" << endl; // Enter name
	cout << "ID @02643836" << endl; // Enter ID number
	cout << "SYCS-135 Computer Science I" << endl; // Enter course
	cout << "Lab 3" << endl; // Enter lab number
	cout << "September 8, 2010" << endl; // Enter date
	cout << "***************************" << endl << endl; // Enter stars
	cout << "AREA CALCULATOR" << endl << endl; // Enter name of program
	cout << "Enter one side of the square=>"; // Ask user to enter side of square
	cin >> side; // Store length of side
	area = side * side; // Calculate area
	cout << "" << endl; // enter blank line
	cout << "The area is " << area << endl; // Output data
	return 0; // return program completed OK to the operating system
}
/****************************
Jeremy Blackstone
ID @02643836
SYCS-135 Computer Science I
Lab 3
September 8, 2010
***************************

AREA CALCULATOR

Enter one side of the square=>10

The area is 100
Press any key to continue . . .*/