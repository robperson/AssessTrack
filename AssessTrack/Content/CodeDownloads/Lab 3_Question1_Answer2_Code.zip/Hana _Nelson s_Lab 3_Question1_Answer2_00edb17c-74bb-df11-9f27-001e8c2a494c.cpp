/* Hana Nelson 
ID @02575836
SYCS-135 Computer Science 1 
Lab 3 
September 8, 2010*/ 

#include <iostream>                        // include input/output library code
#include <string>                          // include string manipulate library code
using namespace std;                       // allows all of the names in a namespace 
                                           // to be accessed without the namespace 
                                           // identifier as a qualifier
int main()
{
	int inches;					           //declare variable 
	cout << "Enter one side of the square=> ";//prompt user input 
	cin >> inches;							//get user input 
	cout << "The area is " <<(inches*inches)<< endl; //mulltiply input by itself 
	cin >> inches;
	return 0;							   //return program completed OK to 
										   //the operating system
}
//Enter one side of the square=>
//12
//The area is 144