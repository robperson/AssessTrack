#include <iostream>   // include input/output library code
#include <string>  // include string manipulate library code

using namespace std; // allows all of the names in a namespace 
int main()           // to be accessed without the namespace 
                    // identifier as a qualifier
{
	float a = 0;    //initialize beginning
	float b = 0 ;    //initialze end
	float square;   //declare square
    float distance = 0; //intitialize distance
    double reimburse = 0; //initialize reimbursement

	cout << "***********************" << endl; // all this is for the
	cout << "Derek West" << endl;              //heading of the program
    cout << "ID @02653583" << endl;
    cout << "SYCS 135 Computer Science I"<< endl;
	cout << "Lab 3"<< endl;
	cout << "September 7, 2010" << endl;
	cout << "***********************"<< endl<<endl;
	cout << "MILEAGE REIMBURSEMENT CALCULATOR"<< endl<<endl;
	
cout << "Enter beginning odometer meter reading => "; //ask for imput
cin >> a;                                         // chage a's value
cout << "Enter ending odometer reading => ";
cin >> b;
distance= b-a;                                    //formula for distance
cout << "You traveled "<< + distance << " miles. ";
reimburse = distance*.35;                          //formula for reimbursement
cout << "At $.35 per mile, your reimbursement is "<< + reimburse << endl; // give answer

	return 0;                       // return program completed OK to
                                           // the operating system
}
/* ***********************
Derek West
ID @02653583
SYCS 135 Computer Science I
Lab 3
September 7, 2010
***********************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer meter reading => 90
Enter ending odometer reading => 165
You traveled 75 miles. At $.35 per mile, your reimbursement is 26.25 */
        