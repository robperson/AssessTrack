#include <iostream>		// include input/output library code
#include <string>		// include string manipulate library code
#include <iomanip>		// allows the output to have two decimal places
using namespace std;	// allows all of the names in a namespace 
						// to be accessed without the namespace 
						// identifier as a qualifier
int main()
{
	cout << "***************************\n";	    // information about student
	cout << "Irving Smith\n";
	cout << "ID @02642732\n";
	cout << "SYCS-135 Computer Science I\n";
	cout << "Assignment 3\n";
	cout << "September 8, 2010\n";
	cout << "***************************\n ";
	cout << " \n";
	cout << "MILEAGE REIMBURSEMENT CALCULATOR\n ";  // name of program
	cout << " \n";
	float beginning;									// insertion of the first variable
	cout << "Enter beginning odometer reading=> ";
	cin >> beginning;								
	float end;										// insertion of the second variable
	cout << "\nEnter ending odometer reading=> ";
	cin >> end;
	cout << fixed << showpoint;						// allows the output to have two decimal places
	cout << setprecision(2) << "\nYou traveled " << end - beginning << " miles. At $.35 per mile, your reimbursement is $" << (end - beginning) * 0.35 << ".\n"; 
	cout << "\n";
	return 0;
/* ***************************
Irving Smith
ID @02642732
SYCS-135 Computer Science I
Assignment 3
September 8, 2010
***************************

MILEAGE REIMBURSEMENT CALCULATOR

Enter beginning odometer reading=> 55044

Enter ending odometer reading=> 55178

You traveled 134.00 miles. At $.35 per mile, your reimbursement is $46.90.

Press any key to continue . . . */
}