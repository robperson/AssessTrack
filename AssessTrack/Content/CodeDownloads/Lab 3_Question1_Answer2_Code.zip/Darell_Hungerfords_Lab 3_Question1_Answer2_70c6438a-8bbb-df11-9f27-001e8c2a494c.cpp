#include<iostream>
#include<string>
using namespace std;

int main() 

{
	   int side;
	   cout << "*************************" << endl;
	   cout << "Darell Hungerford" << endl;
	   cout << "ID@123456" << endl;
	   cout << "SYCS-135 Computer Science I" <<endl;
	   cout << "Lab 3" << endl;
	   cout << "September 7, 2010" << endl;
	   cout << "**************************" << endl;
	   cout << "" << endl;
	   cout << "AREA CALCULATOR"<< endl;
	   cout << "" << endl;
	   cout << "Enter a number of inches of a side => ";
	  
	   cin >> side;

	   cout << "The area is " <<side * side << endl; 
	   
	   return 0;

}
/**************************
Darell Hungerford
ID@123456
SYCS-135 Computer Science I
Lab 3
September 7, 2010
**************************

AREA CALCULATOR

Enter a number of inches of a side => 12
The area is 144
Press any key to continue . . .*/
        