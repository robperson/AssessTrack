#include <iostream>    // include input/output library code
#include <string>      // include string manipulate library code
using namespace std;   // allows all of the names in a namespace
                       // to be accessed without the namespace
                       // identifier as a qualifier

int main()
{
	cout << "AREA CALCULATOR" << endl
	<<endl;
	
    int inches; 	
	cout << "Enter number of inches of one side=> ";        // 2.  prompt the user for their number of inches
    cin >> inches;										   // 3.  get inches from user
	int product=inches*inches;                             // 4.  equation to calculate answer
	cout << "The area is " << product << endl;			   // 4.  output message
   	return 0;								               // return program completed OK to

	//AREA CALCULATOR
	//Enter number of inches of one side=> 12
	//The area is 144
                                                            
}
