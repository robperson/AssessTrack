#include <iostream>      // include input/output library code
using namespace std;     // allows all of the names in a namespace
                         // to be accessed without the namespace
                         // identifier as a qualifier

int main ()
{				
	cout << "***********************" << endl;// heading of the program
	cout << "Cecily Gomes" << endl;                   // Howard Student
	cout << "ID @02652983" << endl;                   // student ID number
	cout << "SYCS-135 Computer Science I" << endl;    // class
	cout << "Lab 3 " << endl;                         // assignment
	cout << "September 8, 2010" << endl;              // date
	cout << "***********************" << endl << endl;                  
	cout << "AREA CALCULATOR" << endl << endl; // 1. name of the program
	int side;                                  // 2. declare variable to store inches
	cout << "Enter one side of the square=> "; // 3. prompt the user for the number of inches of a side
	cin >> side;                               // 4. get number of inches of teh side from user
    cout << endl << "The area is " << side * side << endl; // 5. output message
	system ("pause");						   // 6. Press any key to continue . . .
	return 0;
}


//***********************
//Cecily Gomes
//ID @02652983 
//SYCS-135 Computer Science I
//Lab 3
//September 8, 2010
//*********************** 