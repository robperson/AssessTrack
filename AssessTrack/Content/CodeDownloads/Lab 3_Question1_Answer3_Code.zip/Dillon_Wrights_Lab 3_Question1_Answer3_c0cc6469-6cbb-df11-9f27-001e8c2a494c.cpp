#include <iostream>                     // include input/output library code
#include <iomanip>
using namespace std;                    // allows all of the names in a namespace 
                                        // to be accessed without the namespace 
                                        // identifier as a qualifier
int MILES;                              // 1.  declare variable to store my INT and FLOAT values
int END_MILES;
float DISTANCE;
float RATE;

int main()
{
	cout << fixed << showpoint;

	cout << "Enter beginnining odometer reading." << endl;            // 2.  prompt the user for number
	cin >> MILES;                                                     // 3.  get number from user
    cout << "Enter ending odometer reading." << endl;
	cin >> END_MILES;
	DISTANCE = END_MILES - MILES;
	RATE = DISTANCE * .35;
	cout << "****************" << endl;                            // Writes my information on the screen.  
	cout << "Howard Student" << endl;
	cout << "SYCS-135 Computer I" << endl;
	cout << "Lab 3" << endl;
	cout << "September 8, 2010" << endl;
	cout << "*****************" << endl;
	cout <<endl;
	cout << "Mileage Calculator." << endl;
	     
	cout << "You traveled " << setprecision(2) << DISTANCE << "." << " At .35 cents per mile your reimbursement is $" << RATE << endl;            // 4.  output message

return 0;                                                        // return program completed OK to
                                                                // the operating system
}
//Enter beginnining odometer reading.
//55044
//Enter ending odometer reading.
//55178
//****************
//Howard Student
//SYCS-135 Computer I
//Lab 3
//September 8, 2010
//*****************

Mileage Calculator.
You traveled 134.00. At .35 cents per mile your reimbursement is $
Press any key to continue . . .


        
        