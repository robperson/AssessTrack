#include <iostream>
using namespace std;

int main()
{
	cout << "*********************\n";
	cout << "Howard Student\n";
	cout << "ID @123456\n";
	cout << "SYCS-135 Computer Science 1\n";
	cout << "Lab 3\n";
	cout << "September 7, 2010\n";
	cout << "*********************\n\n";

	int n = 0;
	cout << "AREA CALCULATOR\n\n";
	cout << "Enter the number of inches of a side=> ";
	cin >> n;
	n = n*n;
	cout << endl;
	cout << "The area is " << n;
	cout << "Press any key to continue...";

	return 0;
}

//*********************
//Howard Student
//ID @123456
//SYCS-135 Computer Science 1
//Lab 3
//September 7, 2010
//*********************

//Enter the number of inches of a side=> 9
//The area is 81