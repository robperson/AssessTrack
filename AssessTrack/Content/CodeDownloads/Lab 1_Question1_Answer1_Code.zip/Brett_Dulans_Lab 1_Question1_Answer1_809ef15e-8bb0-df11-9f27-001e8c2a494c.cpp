#include <iostream>
using namespace std;

int main()
{
		cout << "Ohh heck yeah man! COMPUTER SCIENCE!" << endl;
		return 0;
}
        